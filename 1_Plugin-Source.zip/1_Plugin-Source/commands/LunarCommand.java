package fr.lunar.survival.commands;

import fr.lunar.survival.LunarSurvival;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class LunarCommand implements CommandExecutor {

    private final LunarSurvival plugin;

    public LunarCommand(LunarSurvival plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("lunar.admin")) {
            sender.sendMessage("§cPas de permission."); return true;
        }
        if (args.length == 0) { sendHelp(sender); return true; }

        switch (args[0].toLowerCase()) {

            case "tp" -> {
                Player t = resolve(sender, args, 1);
                if (t == null) return true;
                plugin.getLunarWorldManager().teleportToMoon(t);
                sender.sendMessage("§a" + t.getName() + " teleporte sur la Lune !");
            }

            case "station" -> {
                Player t = resolve(sender, args, 1);
                if (t == null) return true;
                plugin.getSpaceStationManager().teleportToStation(t);
                sender.sendMessage("§a" + t.getName() + " teleporte a la station !");
            }

            case "build" -> {
                plugin.getSpaceStationManager().buildStation();
                sender.sendMessage("§a[Station] Construction lancee !");
            }

            case "setday" -> {
                if (args.length < 3) { sender.sendMessage("§cUsage: /lunar setday <joueur> <jour>"); return true; }
                Player t = Bukkit.getPlayer(args[1]);
                if (t == null) { sender.sendMessage("§cJoueur introuvable."); return true; }
                try {
                    int day = Integer.parseInt(args[2]);
                    plugin.getDayManager().setDay(t.getUniqueId(), day);
                    sender.sendMessage("§aJour de " + t.getName() + " -> " + day);
                } catch (NumberFormatException e) { sender.sendMessage("§cNombre invalide."); }
            }

            case "meteor" -> {
                Player t = resolve(sender, args, 1);
                if (t == null) return true;
                plugin.getMeteorManager().launchMeteor(t);
                sender.sendMessage("§a[Meteorite] Lancee vers " + t.getName());
            }

            case "shower" -> {
                Player t = resolve(sender, args, 1);
                if (t == null) return true;
                int count = args.length > 2 ? Integer.parseInt(args[2]) : 5;
                plugin.getMeteorManager().triggerMeteorShower(t, count);
                sender.sendMessage("§a[Pluie] " + count + " meteorites lancees !");
            }

            case "oxygen" -> {
                if (args.length < 3) { sender.sendMessage("§cUsage: /lunar oxygen <joueur> <val>"); return true; }
                Player t = Bukkit.getPlayer(args[1]);
                if (t == null) { sender.sendMessage("§cJoueur introuvable."); return true; }
                try {
                    plugin.getOxygenManager().setOxygen(t.getUniqueId(), Integer.parseInt(args[2]));
                    sender.sendMessage("§aO2 de " + t.getName() + " -> " + args[2] + "%");
                } catch (NumberFormatException e) { sender.sendMessage("§cNombre invalide."); }
            }

            case "info" -> {
                Player t = resolve(sender, args, 1);
                if (t == null) return true;
                int day = plugin.getDayManager().getDay(t);
                int oxy = plugin.getOxygenManager().getOxygen(t.getUniqueId());
                boolean onMoon = plugin.getOxygenManager().isOnMoon(t);
                boolean inStation = plugin.getSpaceStationManager().isInsideStation(t);
                sender.sendMessage("§e--- Info : " + t.getName() + " ---");
                sender.sendMessage("§7Jour    : §e" + day + "/50");
                sender.sendMessage("§7Oxygene : §b" + oxy + "%");
                sender.sendMessage("§7Lune    : " + (onMoon ? "§aOui" : "§cNon"));
                sender.sendMessage("§7Station : " + (inStation ? "§aOui (zone sure)" : "§7Non"));
            }

            default -> sendHelp(sender);
        }
        return true;
    }

    /** Résout un joueur depuis args[index] ou le sender lui-même */
    private Player resolve(CommandSender sender, String[] args, int index) {
        if (args.length > index) {
            Player p = Bukkit.getPlayer(args[index]);
            if (p == null) { sender.sendMessage("§cJoueur introuvable."); return null; }
            return p;
        }
        if (sender instanceof Player p) return p;
        sender.sendMessage("§cSpecifiez un joueur."); return null;
    }

    private void sendHelp(CommandSender s) {
        s.sendMessage("§e§l=== LunarSurvival Admin ===");
        s.sendMessage("§6/lunar tp        §7[joueur]     - Teleporter sur la Lune");
        s.sendMessage("§6/lunar station   §7[joueur]     - Teleporter a la station");
        s.sendMessage("§6/lunar build                   - Reconstruire la station");
        s.sendMessage("§6/lunar setday    §7<joueur> <n> - Changer le jour");
        s.sendMessage("§6/lunar meteor    §7[joueur]     - Lancer une meteorite");
        s.sendMessage("§6/lunar shower    §7[joueur] [n] - Pluie de meteorites");
        s.sendMessage("§6/lunar oxygen    §7<joueur> <v> - Modifier l'oxygene");
        s.sendMessage("§6/lunar info      §7[joueur]     - Voir l'etat du joueur");
    }
}
