package fr.lunar.survival.data;

import fr.lunar.survival.LunarSurvival;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Sauvegarde persistante des données joueurs dans players.yml.
 *
 * Données sauvegardées :
 *  - Jour actuel (survie)
 *  - Nombre de mobs tués
 *  - Nombre de météorites survécues
 *  - Oxygène courant
 *  - Challenge complété ou non
 *
 * Sauvegarde auto toutes les 5 minutes + à chaque déconnexion.
 */
public class DataManager {

    private final LunarSurvival plugin;
    private File dataFile;
    private FileConfiguration dataConfig;

    public DataManager(LunarSurvival plugin) {
        this.plugin = plugin;
        load();
    }

    private void load() {
        dataFile = new File(plugin.getDataFolder(), "players.yml");
        if (!dataFile.exists()) {
            dataFile.getParentFile().mkdirs();
            try { dataFile.createNewFile(); }
            catch (IOException e) { plugin.getLogger().log(Level.SEVERE, "Impossible de creer players.yml", e); }
        }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);
    }

    public void save() {
        try { dataConfig.save(dataFile); }
        catch (IOException e) { plugin.getLogger().log(Level.SEVERE, "Impossible de sauvegarder players.yml", e); }
    }

    // ── Jour ──────────────────────────────────────────────────────────
    public int getDay(UUID id) {
        return dataConfig.getInt(id + ".day", 1);
    }
    public void setDay(UUID id, int day) {
        dataConfig.set(id + ".day", day);
    }

    // ── Oxygène ───────────────────────────────────────────────────────
    public int getOxygen(UUID id) {
        return dataConfig.getInt(id + ".oxygen", 100);
    }
    public void setOxygen(UUID id, int o2) {
        dataConfig.set(id + ".oxygen", o2);
    }

    // ── Mobs tués ─────────────────────────────────────────────────────
    public int getMobsKilled(UUID id) {
        return dataConfig.getInt(id + ".mobsKilled", 0);
    }
    public void setMobsKilled(UUID id, int val) {
        dataConfig.set(id + ".mobsKilled", val);
    }

    // ── Météorites survécues ──────────────────────────────────────────
    public int getMeteorsSurvived(UUID id) {
        return dataConfig.getInt(id + ".meteorsSurvived", 0);
    }
    public void setMeteorsSurvived(UUID id, int val) {
        dataConfig.set(id + ".meteorsSurvived", val);
    }

    // ── Challenge complété ────────────────────────────────────────────
    public boolean isCompleted(UUID id) {
        return dataConfig.getBoolean(id + ".completed", false);
    }
    public void setCompleted(UUID id, boolean val) {
        dataConfig.set(id + ".completed", val);
    }

    // ── Première connexion ────────────────────────────────────────────
    public boolean hasJoined(UUID id) {
        return dataConfig.contains(id + ".day");
    }
    public void markJoined(UUID id) {
        if (!hasJoined(id)) {
            setDay(id, 1);
            setOxygen(id, 100);
            setMobsKilled(id, 0);
            setMeteorsSurvived(id, 0);
            setCompleted(id, false);
            save();
        }
    }
}
