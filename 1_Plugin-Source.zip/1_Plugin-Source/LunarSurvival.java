package fr.lunar.survival;

import fr.lunar.survival.commands.LunarCommand;
import fr.lunar.survival.crafting.LunarCraftingManager;
import fr.lunar.survival.crafting.OxygenKitListener;
import fr.lunar.survival.data.DataManager;
import fr.lunar.survival.generators.MoonChunkGenerator;
import fr.lunar.survival.listeners.*;
import fr.lunar.survival.managers.*;
import fr.lunar.survival.mobs.LunarMobManager;
import fr.lunar.survival.mobs.MobDeathListener;
import fr.lunar.survival.scoreboard.LunarScoreboardManager;
import fr.lunar.survival.station.SpaceStationManager;
import fr.lunar.survival.station.StationZoneListener;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.plugin.java.JavaPlugin;

public class LunarSurvival extends JavaPlugin {

    private static LunarSurvival instance;

    private DataManager            dataManager;
    private LunarWorldManager      lunarWorldManager;
    private OxygenManager          oxygenManager;
    private DayManager             dayManager;
    private GravityManager         gravityManager;
    private MeteorManager          meteorManager;
    private LunarMobManager        lunarMobManager;
    private LunarCraftingManager   craftingManager;
    private LunarScoreboardManager scoreboardManager;
    private SpaceStationManager    spaceStationManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        // Init dans l'ordre
        this.dataManager          = new DataManager(this);
        this.lunarWorldManager    = new LunarWorldManager(this);
        this.oxygenManager        = new OxygenManager(this);
        this.dayManager           = new DayManager(this);
        this.gravityManager       = new GravityManager(this);
        this.meteorManager        = new MeteorManager(this);
        this.lunarMobManager      = new LunarMobManager(this);
        this.scoreboardManager    = new LunarScoreboardManager(this);
        this.craftingManager      = new LunarCraftingManager(this);
        this.spaceStationManager  = new SpaceStationManager(this);

        craftingManager.registerRecipes();

        // Station construite après 3 secondes (monde chargé)
        getServer().getScheduler().runTaskLater(this, () -> {
            spaceStationManager.buildStation();
        }, 60L);

        // Listeners
        StationZoneListener stationZoneListener = new StationZoneListener(this);
        getServer().getPluginManager().registerEvents(new PlayerJoinListener(this),  this);
        getServer().getPluginManager().registerEvents(new PlayerQuitListener(this),  this);
        getServer().getPluginManager().registerEvents(new HelmetListener(this),      this);
        getServer().getPluginManager().registerEvents(new PortalListener(this),      this);
        getServer().getPluginManager().registerEvents(new MeteorListener(this),      this);
        getServer().getPluginManager().registerEvents(new LootListener(this),        this);
        getServer().getPluginManager().registerEvents(new MobDeathListener(this),    this);
        getServer().getPluginManager().registerEvents(new OxygenKitListener(this),   this);
        getServer().getPluginManager().registerEvents(new KillTrackListener(this),   this);
        getServer().getPluginManager().registerEvents(craftingManager,               this);
        getServer().getPluginManager().registerEvents(stationZoneListener,           this);

        // Commandes
        getCommand("lunar").setExecutor(new LunarCommand(this));

        // Tâches
        oxygenManager.startTask();
        dayManager.startTask();
        gravityManager.startTask();
        meteorManager.startTask();
        lunarMobManager.startTask();
        scoreboardManager.startTask();

        // Auto-save 5 min
        getServer().getScheduler().runTaskTimerAsynchronously(this,
            () -> dataManager.save(), 20L * 60 * 5, 20L * 60 * 5);

        getLogger().info("==========================================");
        getLogger().info("  LunarSurvival 2.1 — Java + Bedrock");
        getLogger().info("  Station spatiale : construction...");
        getLogger().info("  Generateur lunaire : crateres + minerais");
        getLogger().info("  Mobs : 4 types de monstres lunaires");
        getLogger().info("  Crafts spatiaux : 5 recettes exclusives");
        getLogger().info("  Scoreboard + sauvegarde persistante");
        getLogger().info("==========================================");
    }

    @Override
    public void onDisable() {
        dataManager.save();
        getLogger().info("LunarSurvival sauvegarde et desactive.");
    }

    @Override
    public ChunkGenerator getDefaultWorldGenerator(String worldName, String id) {
        if ("lunar_moon".equals(worldName)) return new MoonChunkGenerator();
        return null;
    }

    public static LunarSurvival     getInstance()             { return instance; }
    public DataManager              getDataManager()           { return dataManager; }
    public OxygenManager            getOxygenManager()         { return oxygenManager; }
    public DayManager               getDayManager()            { return dayManager; }
    public GravityManager           getGravityManager()        { return gravityManager; }
    public MeteorManager            getMeteorManager()         { return meteorManager; }
    public LunarMobManager          getLunarMobManager()       { return lunarMobManager; }
    public LunarWorldManager        getLunarWorldManager()     { return lunarWorldManager; }
    public LunarScoreboardManager   getScoreboardManager()     { return scoreboardManager; }
    public LunarCraftingManager     getCraftingManager()       { return craftingManager; }
    public SpaceStationManager      getSpaceStationManager()   { return spaceStationManager; }
}
