package fr.lunar.survival.listeners;

import fr.lunar.survival.BedrockCompat;
import fr.lunar.survival.LunarSurvival;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class MeteorListener implements Listener {

    private final LunarSurvival plugin;

    public MeteorListener(LunarSurvival plugin) { this.plugin = plugin; }

    @EventHandler
    public void onMeteorExplode(EntityExplodeEvent event) {
        if (!event.getLocation().getWorld().getName()
                .equals(plugin.getLunarWorldManager().getMoonWorldName())) return;

        Location loc = event.getLocation();
        World world = loc.getWorld();

        // Shockwave — pousse les joueurs proches
        for (Player player : world.getPlayers()) {
            double dist = player.getLocation().distance(loc);
            if (dist < 15) {
                org.bukkit.util.Vector push = player.getLocation().toVector()
                    .subtract(loc.toVector()).normalize().multiply(2.0 / (dist + 1));
                push.setY(Math.abs(push.getY()) + 0.5);
                player.setVelocity(push);
                player.sendMessage(BedrockCompat.MSG_METEOR_IMPACT);
            }
        }

        // 40% de chance de dropper un fragment lunaire
        if (Math.random() < 0.4) {
            world.dropItem(loc, buildLunarFragment());
        }

        // Particules compatibles Java + Bedrock via Geyser
        world.spawnParticle(Particle.EXPLOSION_HUGE, loc, 5,  1, 1, 1, 0.1);
        world.spawnParticle(Particle.SMOKE_LARGE,    loc, 30, 2, 2, 2, 0.1);
        // FALLING_DUST mappe vers "fallingDustParticle" cote Bedrock
        world.spawnParticle(Particle.FALLING_DUST,  loc, 50, 3, 1, 3, 0.2,
            Material.END_STONE.createBlockData());

        // Son sur Java + Bedrock
        for (Player p : world.getPlayers()) {
            p.playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 1f, 0.5f);
        }
    }

    private ItemStack buildLunarFragment() {
        Material[] mats = {
            Material.IRON_ORE, Material.GOLD_ORE, Material.DIAMOND,
            Material.EMERALD,  Material.QUARTZ,   Material.AMETHYST_SHARD
        };
        Material mat = mats[(int)(Math.random() * mats.length)];
        int amount = 1 + (int)(Math.random() * 4);
        ItemStack item = new ItemStack(mat, amount);
        ItemMeta meta = item.getItemMeta();
        // Nom sans emoji — compatible Bedrock
        meta.setDisplayName(BedrockCompat.ITEM_METEOR_FRAGMENT + " [" + mat.name() + "]");
        item.setItemMeta(meta);
        return item;
    }
}
