package fr.lunar.survival.listeners;

import fr.lunar.survival.BedrockCompat;
import fr.lunar.survival.LunarSurvival;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;

public class PlayerJoinListener implements Listener {

    private final LunarSurvival plugin;

    public PlayerJoinListener(LunarSurvival plugin) { this.plugin = plugin; }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        if (!player.hasPlayedBefore()) {
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                giveStarterKit(player);
                plugin.getLunarWorldManager().teleportToMoon(player);
            }, 40L);
        } else {
            int day = plugin.getDayManager().getDay(player);
            if (day > 0 && day <= 50 && !plugin.getOxygenManager().isOnMoon(player)) {
                plugin.getLunarWorldManager().teleportToMoon(player);
            }
            player.sendMessage("§e[Lune] Bon retour ! Jour §f" + day + "§e/50");
        }
    }

    private void giveStarterKit(Player player) {
        // ── Armure complète en fer ────────────────────────────────────
        ItemStack helmet = new ItemStack(Material.IRON_HELMET);
        ItemMeta helmetMeta = helmet.getItemMeta();
        helmetMeta.setDisplayName(BedrockCompat.ITEM_HELMET_NAME);
        helmetMeta.setLore(Arrays.asList(
            BedrockCompat.ITEM_HELMET_LORE1,
            BedrockCompat.ITEM_HELMET_LORE2
        ));
        helmet.setItemMeta(helmetMeta);
        player.getInventory().setHelmet(helmet);
        player.getInventory().setChestplate(new ItemStack(Material.IRON_CHESTPLATE));
        player.getInventory().setLeggings  (new ItemStack(Material.IRON_LEGGINGS));
        player.getInventory().setBoots     (new ItemStack(Material.IRON_BOOTS));

        // ── Outils ───────────────────────────────────────────────────
        player.getInventory().addItem(
            new ItemStack(Material.STONE_PICKAXE),
            new ItemStack(Material.STONE_SWORD),
            new ItemStack(Material.STONE_SHOVEL)
        );

        // ── Réserve d'oxygène (item cosmetique) ──────────────────────
        ItemStack oxyTank = new ItemStack(Material.GLASS_BOTTLE, 3);
        ItemMeta tankMeta = oxyTank.getItemMeta();
        tankMeta.setDisplayName(BedrockCompat.ITEM_OXY_TANK_NAME);
        tankMeta.setLore(Arrays.asList(
            BedrockCompat.ITEM_OXY_TANK_LORE1,
            BedrockCompat.ITEM_OXY_TANK_LORE2
        ));
        oxyTank.setItemMeta(tankMeta);
        player.getInventory().addItem(oxyTank);

        // ── Nourriture ───────────────────────────────────────────────
        player.getInventory().addItem(
            new ItemStack(Material.BREAD,       16),
            new ItemStack(Material.COOKED_BEEF, 64)  // 64 steaks cuits
        );

        // ── Buches de chene x64 (ressource de base pour tout crafter) ─
        player.getInventory().addItem(new ItemStack(Material.OAK_LOG, 64));

        // ── Torches ──────────────────────────────────────────────────
        player.getInventory().addItem(new ItemStack(Material.TORCH, 32));

        // ── Message de bienvenue ─────────────────────────────────────
        player.sendMessage("§7----------------------------------");
        player.sendMessage("§a[OK] Kit de depart recu !");
        player.sendMessage("§7  * Armure fer + casque spatial");
        player.sendMessage("§7  * 64 steaks cuits");
        player.sendMessage("§7  * 64 buches de chene");
        player.sendMessage("§7  * Outils pierre + torches");
        player.sendMessage("§c  ! N'enlevez JAMAIS votre casque dehors !");
        player.sendMessage("§7----------------------------------");
    }
}
