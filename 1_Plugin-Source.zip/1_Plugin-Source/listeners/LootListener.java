package fr.lunar.survival.listeners;

import fr.lunar.survival.BedrockCompat;
import fr.lunar.survival.LunarSurvival;
import org.bukkit.*;
import org.bukkit.block.Chest;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

public class LootListener implements Listener {

    private final LunarSurvival plugin;
    private final Set<Location> looted = new HashSet<>();

    public LootListener(LunarSurvival plugin) { this.plugin = plugin; }

    @EventHandler
    public void onChestOpen(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getClickedBlock() == null) return;
        if (event.getClickedBlock().getType() != Material.CHEST) return;

        Player player = event.getPlayer();
        if (!plugin.getOxygenManager().isOnMoon(player)) return;

        Location loc = event.getClickedBlock().getLocation();
        if (looted.contains(loc)) return;
        looted.add(loc);

        Chest chest = (Chest) event.getClickedBlock().getState();
        fillLunarChest(chest);
    }

    private void fillLunarChest(Chest chest) {
        Random rand = new Random();
        chest.getInventory().clear();

        // Noms sans emoji — identiques Java + Bedrock
        List<ItemStack> possible = Arrays.asList(
            named(new ItemStack(Material.IRON_HELMET),                      BedrockCompat.ITEM_HELMET_SPARE),
            named(new ItemStack(Material.DIAMOND,     2 + rand.nextInt(3)), BedrockCompat.ITEM_DIAMOND_LUNAR),
            named(new ItemStack(Material.BREAD,       8 + rand.nextInt(8)), BedrockCompat.ITEM_FOOD_RATION),
            named(new ItemStack(Material.IRON_INGOT,  4 + rand.nextInt(6)), BedrockCompat.ITEM_IRON_ALLOY),
            named(new ItemStack(Material.GOLD_INGOT,  2 + rand.nextInt(4)), BedrockCompat.ITEM_GOLD_METEOR),
            named(new ItemStack(Material.TORCH,       16),                   BedrockCompat.ITEM_TORCH_SPACE),
            named(new ItemStack(Material.TNT,          2),                   BedrockCompat.ITEM_TNT_CHARGE),
            named(new ItemStack(Material.ENDER_PEARL,  1 + rand.nextInt(2)),BedrockCompat.ITEM_PEARL_QUANTUM),
            new ItemStack(Material.COOKED_BEEF,        6),
            new ItemStack(Material.OBSIDIAN,           2 + rand.nextInt(4))
        );

        Collections.shuffle(possible);
        int count = 3 + rand.nextInt(4);
        for (int i = 0; i < Math.min(count, possible.size()); i++) {
            chest.getInventory().setItem(rand.nextInt(27), possible.get(i));
        }
        chest.update();
    }

    private ItemStack named(ItemStack item, String name) {
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        item.setItemMeta(meta);
        return item;
    }
}
