package fr.lunar.survival.listeners;

import fr.lunar.survival.LunarSurvival;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.UUID;

public class PlayerQuitListener implements Listener {

    private final LunarSurvival plugin;

    public PlayerQuitListener(LunarSurvival plugin) { this.plugin = plugin; }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID id = player.getUniqueId();

        // Sauvegarder les données persistantes
        plugin.getDataManager().setDay(id, plugin.getDayManager().getDay(player));
        plugin.getDataManager().setOxygen(id, plugin.getOxygenManager().getOxygen(id));
        plugin.getDataManager().setMobsKilled(id, plugin.getScoreboardManager().getKills(id));
        plugin.getDataManager().setMeteorsSurvived(id, plugin.getScoreboardManager().getMeteors(id));
        plugin.getDataManager().save();
    }
}
