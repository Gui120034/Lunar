package fr.lunar.survival.listeners;

import fr.lunar.survival.BedrockCompat;
import fr.lunar.survival.LunarSurvival;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

public class HelmetListener implements Listener {

    private final LunarSurvival plugin;

    public HelmetListener(LunarSurvival plugin) { this.plugin = plugin; }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!plugin.getOxygenManager().isOnMoon(player)) return;

        // Delai 1 tick pour que l'inventaire se mette a jour
        new BukkitRunnable() {
            @Override public void run() { checkHelmet(player); }
        }.runTaskLater(plugin, 1L);
    }

    private void checkHelmet(Player player) {
        if (plugin.getOxygenManager().hasSpaceHelmet(player)) return;

        // Blindness total (ecran noir) — effet de potion, identique Java + Bedrock
        player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 200, 5,  false, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,      100, 3,  false, false));

        // Particules SMOKE_LARGE — mappees par Geyser vers Bedrock
        player.getWorld().spawnParticle(
            Particle.SMOKE_LARGE,
            player.getLocation().add(0, 1.8, 0),
            30, 0.5, 0.5, 0.5, 0.05
        );

        // Message sans emoji
        player.sendMessage(BedrockCompat.MSG_HELMET_REMOVED);

        // Son sur Java + Bedrock
        player.playSound(player.getLocation(), Sound.ENTITY_CREEPER_HURT, 1f, 0.5f);

        // Titre via Adventure API — identique Java + Bedrock
        BedrockCompat.sendTitle(player,
            BedrockCompat.TITLE_NO_HELMET,
            BedrockCompat.TITLE_NO_HELMET_SUB,
            0, 60, 10
        );
    }
}
