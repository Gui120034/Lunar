package fr.lunar.survival.listeners;

import fr.lunar.survival.LunarSurvival;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityDeathEvent;

public class KillTrackListener implements Listener {

    private final LunarSurvival plugin;

    public KillTrackListener(LunarSurvival plugin) { this.plugin = plugin; }

    @EventHandler
    public void onKill(EntityDeathEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.getKiller() == null) return;
        if (!plugin.getOxygenManager().isOnMoon(entity.getKiller())) return;
        if (entity.getCustomName() == null) return; // Seulement les mobs lunaires custom

        plugin.getScoreboardManager().incrementKills(entity.getKiller().getUniqueId());
    }
}
