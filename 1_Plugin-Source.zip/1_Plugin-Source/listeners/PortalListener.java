package fr.lunar.survival.listeners;

import fr.lunar.survival.BedrockCompat;
import fr.lunar.survival.LunarSurvival;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

public class PortalListener implements Listener {

    private final LunarSurvival plugin;

    public PortalListener(LunarSurvival plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPortalUse(PlayerPortalEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getOxygenManager().isOnMoon(player)) return;

        int day = plugin.getDayManager().getDay(player);
        if (day < 50) {
            event.setCancelled(true);
            player.sendMessage(BedrockCompat.MSG_PORTAL_BLOCKED);
            player.sendMessage("§7  Jour actuel : §e" + day + "§7 / §650");
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onTeleport(PlayerTeleportEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getOxygenManager().isOnMoon(player)) return;
        if (event.getTo() == null || event.getTo().getWorld() == null) return;
        if (event.getTo().getWorld().getName().equals(plugin.getLunarWorldManager().getMoonWorldName())) return;

        int day = plugin.getDayManager().getDay(player);
        if (day < 50 && event.getCause() != PlayerTeleportEvent.TeleportCause.PLUGIN) {
            event.setCancelled(true);
            player.sendMessage(BedrockCompat.MSG_PORTAL_BLOCKED2 + " (" + day + "/50 jours)");
        }
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        World moonWorld = plugin.getLunarWorldManager().getMoonWorld();
        if (moonWorld == null) return;

        int day = plugin.getDayManager().getDay(player);
        if (day > 0 && day <= 50) {
            Location spawnLoc = moonWorld.getSpawnLocation();
            spawnLoc.setY(moonWorld.getHighestBlockYAt(0, 0) + 2);
            event.setRespawnLocation(spawnLoc);
            plugin.getOxygenManager().setOxygen(player.getUniqueId(), 100);
            player.sendMessage("§c[Mort] Vous etes mort... mais la Lune vous retient.");
            player.sendMessage("§7Oxygene remis a 100%. Jour §e" + day + "§7/50.");
        }
    }
}
