package fr.lunar.survival.generators;

import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.WorldInfo;

import java.util.Random;

/**
 * Générateur de terrain lunaire custom.
 *
 * Terrain généré :
 *  - Sol principal  : END_STONE (régolithe lunaire)
 *  - Sous-sol       : END_STONE avec poches de STONE et DEEPSLATE
 *  - Cratères       : dépressions circulaires creusées dans le sol
 *  - Minerais       : IRON_ORE, GOLD_ORE, DIAMOND_ORE enfouis
 *  - Rochers        : piliers / blocs épars en surface
 *  - Ciel           : complètement vide (pas de nuages, pas d'air chargé)
 *
 * Compatible Java + Bedrock : le générateur tourne côté serveur,
 * Geyser reçoit les chunks déjà générés → rendu identique.
 */
public class MoonChunkGenerator extends ChunkGenerator {

    // Hauteurs
    private static final int BASE_Y      = 60;   // Hauteur du sol de base
    private static final int TERRAIN_VAR =  6;   // Variation de hauteur max
    private static final int DEPTH       = 20;   // Profondeur du sous-sol

    // Probabilités
    private static final double CRATER_CHANCE  = 0.012; // par chunk
    private static final double ROCK_CHANCE    = 0.04;
    private static final double IRON_CHANCE    = 0.018;
    private static final double GOLD_CHANCE    = 0.008;
    private static final double DIAMOND_CHANCE = 0.003;
    private static final double QUARTZ_CHANCE  = 0.006;

    @Override
    public void generateNoise(WorldInfo worldInfo, Random rand, int chunkX, int chunkZ,
                              ChunkData chunk) {

        // ── Terrain de base ──────────────────────────────────────────────
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {

                // Hauteur de surface avec ondulation douce (bruit simple)
                int surfaceY = BASE_Y + (int)(Math.sin(
                    (chunkX * 16 + x) * 0.08 + (chunkZ * 16 + z) * 0.07
                ) * TERRAIN_VAR * 0.5 + rand.nextInt(TERRAIN_VAR));

                // Remplissage du sous-sol
                for (int y = surfaceY - DEPTH; y <= surfaceY; y++) {
                    if (y <= surfaceY - 3) {
                        // Couches profondes : mélange END_STONE / STONE / DEEPSLATE
                        double r = rand.nextDouble();
                        if      (r < 0.60) chunk.setBlock(x, y, z, Material.END_STONE);
                        else if (r < 0.80) chunk.setBlock(x, y, z, Material.STONE);
                        else               chunk.setBlock(x, y, z, Material.DEEPSLATE);
                    } else {
                        // Couches supérieures : régolithe pur
                        chunk.setBlock(x, y, z, Material.END_STONE);
                    }
                }

                // Minerais enfouis
                for (int y = surfaceY - DEPTH + 1; y < surfaceY - 1; y++) {
                    double r = rand.nextDouble();
                    if      (r < DIAMOND_CHANCE) chunk.setBlock(x, y, z, Material.DIAMOND_ORE);
                    else if (r < DIAMOND_CHANCE + GOLD_CHANCE)
                                                 chunk.setBlock(x, y, z, Material.GOLD_ORE);
                    else if (r < DIAMOND_CHANCE + GOLD_CHANCE + IRON_CHANCE)
                                                 chunk.setBlock(x, y, z, Material.IRON_ORE);
                    else if (r < DIAMOND_CHANCE + GOLD_CHANCE + IRON_CHANCE + QUARTZ_CHANCE)
                                                 chunk.setBlock(x, y, z, Material.NETHER_QUARTZ_ORE);
                }
            }
        }

        // ── Cratères ─────────────────────────────────────────────────────
        if (rand.nextDouble() < CRATER_CHANCE) {
            int cx = rand.nextInt(16);
            int cz = rand.nextInt(16);
            int radius = 3 + rand.nextInt(6); // rayon 3–8
            digCrater(chunk, cx, BASE_Y, cz, radius, rand);
        }

        // ── Rochers de surface ───────────────────────────────────────────
        for (int x = 2; x < 14; x++) {
            for (int z = 2; z < 14; z++) {
                if (rand.nextDouble() < ROCK_CHANCE) {
                    int surfaceY = getSurfaceY(chunk, x, z);
                    placeRock(chunk, x, surfaceY + 1, z, rand);
                }
            }
        }
    }

    /** Creuse un cratère circulaire avec rebords surélevés */
    private void digCrater(ChunkData chunk, int cx, int baseY, int cz, int radius, Random rand) {
        for (int x = Math.max(0, cx - radius - 1); x < Math.min(16, cx + radius + 2); x++) {
            for (int z = Math.max(0, cz - radius - 1); z < Math.min(16, cz + radius + 2); z++) {
                double dist = Math.sqrt((x - cx) * (x - cx) + (z - cz) * (z - cz));

                if (dist < radius) {
                    // Intérieur : creuser
                    int depth = (int)(3 * (1 - dist / radius)) + 1;
                    for (int dy = 0; dy <= depth + 2; dy++) {
                        chunk.setBlock(x, baseY - dy + 2, z, Material.AIR);
                    }
                    // Fond du cratère : BLACKSTONE (basalte lunaire)
                    chunk.setBlock(x, baseY - depth, z, Material.BLACKSTONE);

                } else if (dist < radius + 1.5) {
                    // Rebord : légère surélévation
                    int height = (int)((1.5 - (dist - radius)) * 2);
                    for (int dy = 1; dy <= height; dy++) {
                        int surfY = getSurfaceY(chunk, x, z);
                        if (surfY + dy < 256)
                            chunk.setBlock(x, surfY + dy, z, Material.END_STONE);
                    }
                }
            }
        }
    }

    /** Place un rocher/pilier de 1–4 blocs de haut */
    private void placeRock(ChunkData chunk, int x, int y, int z, Random rand) {
        int height = 1 + rand.nextInt(3);
        Material mat = rand.nextDouble() < 0.3 ? Material.STONE : Material.END_STONE;
        for (int dy = 0; dy < height; dy++) {
            if (y + dy < 256) chunk.setBlock(x, y + dy, z, mat);
        }
    }

    /** Trouve la surface Y d'une colonne dans le chunk */
    private int getSurfaceY(ChunkData chunk, int x, int z) {
        for (int y = BASE_Y + TERRAIN_VAR + 5; y > 0; y--) {
            if (chunk.getType(x, y, z) != Material.AIR) return y;
        }
        return BASE_Y;
    }

    @Override
    public boolean shouldGenerateNoise()       { return false; }
    @Override
    public boolean shouldGenerateSurface()     { return false; }
    @Override
    public boolean shouldGenerateBedrock()     { return false; }
    @Override
    public boolean shouldGenerateCaves()       { return false; }
    @Override
    public boolean shouldGenerateDecorations() { return false; }
    @Override
    public boolean shouldGenerateMobs()        { return false; }
    @Override
    public boolean shouldGenerateStructures()  { return false; }
}
