package fr.lunar.survival.mobs;

import fr.lunar.survival.LunarSurvival;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.Random;

public class MobDeathListener implements Listener {

    private final LunarSurvival plugin;
    private final Random rand = new Random();

    public MobDeathListener(LunarSurvival plugin) { this.plugin = plugin; }

    // ── Drops custom à la mort des mobs lunaires ──────────────────────
    @EventHandler
    public void onMobDeath(EntityDeathEvent event) {
        LivingEntity entity = event.getEntity();
        if (!plugin.getOxygenManager().isOnMoon(entity)) return;
        if (entity.getCustomName() == null) return;

        String name = entity.getCustomName();
        event.getDrops().clear();
        event.setDroppedExp(0);

        Location loc = entity.getLocation();

        if (name.contains("Spectre Lunaire")) {
            dropItem(loc, Material.PHANTOM_MEMBRANE, 1 + rand.nextInt(3));
            dropItem(loc, Material.AMETHYST_SHARD,   rand.nextInt(3));
            event.setDroppedExp(15 + rand.nextInt(20));

        } else if (name.contains("Araignee de Cratere")) {
            dropItem(loc, Material.STRING,            2 + rand.nextInt(4));
            dropItem(loc, Material.SPIDER_EYE,        rand.nextInt(2));
            if (rand.nextDouble() < 0.2)
                dropItem(loc, Material.IRON_INGOT, 1);
            event.setDroppedExp(12 + rand.nextInt(15));

        } else if (name.contains("Golem de Regolithe")) {
            // Boss = drops riches
            dropItem(loc, Material.IRON_INGOT,        4 + rand.nextInt(6));
            dropItem(loc, Material.GOLD_INGOT,        2 + rand.nextInt(4));
            if (rand.nextDouble() < 0.5)
                dropItem(loc, Material.DIAMOND, 1 + rand.nextInt(2));
            if (rand.nextDouble() < 0.15)
                dropLunarCrystal(loc);
            event.setDroppedExp(80 + rand.nextInt(40));

        } else if (name.contains("Cosmonaute Corrompu")) {
            dropItem(loc, Material.ROTTEN_FLESH,      1 + rand.nextInt(3));
            if (rand.nextDouble() < 0.25)
                dropItem(loc, Material.IRON_NUGGET, 2 + rand.nextInt(4));
            if (rand.nextDouble() < 0.10)
                dropItem(loc, Material.GLASS_BOTTLE, 1); // Réserve d'O2 symbolique
            event.setDroppedExp(10 + rand.nextInt(10));
        }
    }

    // ── Drain d'oxygène quand un Spectre Lunaire attaque ─────────────
    @EventHandler
    public void onMobAttack(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Phantom phantom)) return;
        if (!(event.getEntity() instanceof Player player)) return;
        if (phantom.getCustomName() == null) return;
        if (!phantom.getCustomName().contains("Spectre Lunaire")) return;

        // Le Spectre draine l'oxygène en plus des dégâts normaux
        int currentO2 = plugin.getOxygenManager().getOxygen(player.getUniqueId());
        int drain = 20 + rand.nextInt(15); // Draine 20-35% d'O2
        plugin.getOxygenManager().setOxygen(player.getUniqueId(), currentO2 - drain);

        player.sendMessage("§c[Spectre] Votre oxygene est draine ! O2: §f" +
            Math.max(0, currentO2 - drain) + "%");
        player.playSound(player.getLocation(), Sound.ENTITY_CREEPER_HURT, 0.7f, 0.4f);
    }

    // ── Helpers ───────────────────────────────────────────────────────
    private void dropItem(Location loc, Material mat, int amount) {
        loc.getWorld().dropItemNaturally(loc, new ItemStack(mat, amount));
    }

    private void dropLunarCrystal(Location loc) {
        ItemStack crystal = new ItemStack(Material.AMETHYST_SHARD, 3);
        ItemMeta meta = crystal.getItemMeta();
        meta.setDisplayName("§d[Cristal Lunaire]");
        meta.setLore(Arrays.asList(
            "§7Extrait d'un Golem de Regolithe.",
            "§eSert a crafter de l'equipement spatial avance."
        ));
        crystal.setItemMeta(meta);
        loc.getWorld().dropItemNaturally(loc, crystal);
    }

    // ── Vérification si l'entité est dans le monde lunaire ───────────
    private boolean isOnMoon(LivingEntity entity) {
        return entity.getWorld().getName()
            .equals(plugin.getLunarWorldManager().getMoonWorldName());
    }
}
