package fr.lunar.survival.mobs;

import fr.lunar.survival.LunarSurvival;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Random;

/**
 * Gestion des monstres lunaires.
 *
 * Types de monstres spéciaux :
 *
 *  [1] FANTOME LUNAIRE (Phantom modifié)
 *      - Vol + attaque plongée
 *      - Applique Blindness (perte d'oxygène simulée)
 *      - Nom : "Spectre Lunaire"
 *
 *  [2] ARAIGNEE DE CRATERE (Spider modifiée)
 *      - Vitesse accrue (lune = saut)
 *      - Résistance aux dégâts
 *      - Nom : "Araignee de Cratere"
 *
 *  [3] GOLEM DE REGOLITHE (Iron Golem modifié)
 *      - HP très élevés, dégâts massifs
 *      - Apparaît seulement à partir du Jour 20
 *      - Drop : minerais lunaires rares
 *      - Nom : "Golem de Regolithe"
 *
 *  [4] ZOMBIE COSMONAUTE (Zombie modifié)
 *      - Porte un casque (symbolique)
 *      - Résistance au feu
 *      - Nom : "Cosmonaute Corrompu"
 *
 * Spawn : toutes les 3 minutes, 1–3 monstres par joueur sur la Lune.
 * Seuls les monstres lunaires custom spawn (MOB_SPAWNING naturel désactivé).
 */
public class LunarMobManager {

    private final LunarSurvival plugin;
    private final Random rand = new Random();

    // Spawn toutes les 3 minutes
    private static final long SPAWN_INTERVAL_TICKS = 20L * 60 * 3;

    public LunarMobManager(LunarSurvival plugin) {
        this.plugin = plugin;
    }

    public void startTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                World moonWorld = plugin.getLunarWorldManager().getMoonWorld();
                if (moonWorld == null) return;

                for (Player player : moonWorld.getPlayers()) {
                    int day = plugin.getDayManager().getDay(player);
                    int mobCount = getMobCountForDay(day);

                    for (int i = 0; i < mobCount; i++) {
                        spawnLunarMob(player, day);
                    }
                }
            }
        }.runTaskTimer(plugin, 20L * 30, SPAWN_INTERVAL_TICKS); // Premier spawn après 30s
    }

    /** Nombre de mobs à spawner selon le jour */
    private int getMobCountForDay(int day) {
        if (day <= 5)  return 1;
        if (day <= 15) return rand.nextInt(2) + 1; // 1-2
        if (day <= 30) return rand.nextInt(2) + 2; // 2-3
        return rand.nextInt(3) + 2;                // 2-4
    }

    /** Choisit et spawne un mob lunaire selon le jour */
    private void spawnLunarMob(Player player, int day) {
        Location loc = getSpawnLocation(player);
        if (loc == null) return;

        // Sélection du type selon probabilité + jour
        double r = rand.nextDouble();

        if (day >= 20 && r < 0.10) {
            spawnRegalithGolem(loc);
        } else if (r < 0.35) {
            spawnLunarPhantom(loc);
        } else if (r < 0.65) {
            spawnCraterSpider(loc);
        } else {
            spawnCorruptedCosmonaut(loc);
        }
    }

    /** Trouve un emplacement de spawn valide (8-20 blocs du joueur) */
    private Location getSpawnLocation(Player player) {
        Location base = player.getLocation();
        World world = base.getWorld();

        for (int attempt = 0; attempt < 10; attempt++) {
            double angle = rand.nextDouble() * Math.PI * 2;
            double dist  = 8 + rand.nextDouble() * 12;
            int dx = (int)(Math.cos(angle) * dist);
            int dz = (int)(Math.sin(angle) * dist);

            Location candidate = base.clone().add(dx, 0, dz);
            int y = world.getHighestBlockYAt(candidate) + 1;
            candidate.setY(y);

            // Vérifier que l'emplacement est sur un bloc solide
            if (candidate.getBlock().getType() == Material.AIR &&
                candidate.clone().subtract(0, 1, 0).getBlock().getType() != Material.AIR) {
                return candidate;
            }
        }
        return null;
    }

    // ─────────────────────────────────────────────────────
    //  MOB 1 : SPECTRE LUNAIRE (Phantom)
    // ─────────────────────────────────────────────────────
    private void spawnLunarPhantom(Location loc) {
        Phantom phantom = (Phantom) loc.getWorld().spawnEntity(loc, EntityType.PHANTOM);
        phantom.setCustomName("§b[Spectre Lunaire]");
        phantom.setCustomNameVisible(true);
        phantom.setSize(2); // Plus grand que normal

        // HP augmenté
        if (phantom.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null) {
            phantom.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(40.0);
            phantom.setHealth(40.0);
        }

        // Attaque qui draine l'oxygène (applique Blindness = simulé)
        phantom.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1, false, false));

        // Aura brillante pour le distinguer (Glowing)
        phantom.setGlowing(true);
    }

    // ─────────────────────────────────────────────────────
    //  MOB 2 : ARAIGNEE DE CRATERE (Spider)
    // ─────────────────────────────────────────────────────
    private void spawnCraterSpider(Location loc) {
        Spider spider = (Spider) loc.getWorld().spawnEntity(loc, EntityType.SPIDER);
        spider.setCustomName("§8[Araignee de Cratere]");
        spider.setCustomNameVisible(true);

        if (spider.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null) {
            spider.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(30.0);
            spider.setHealth(30.0);
        }
        if (spider.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED) != null) {
            spider.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED).setBaseValue(0.45); // Très rapide
        }

        // Résistance
        spider.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 0, false, false));
        spider.setGlowing(true);
    }

    // ─────────────────────────────────────────────────────
    //  MOB 3 : GOLEM DE REGOLITHE (Iron Golem)
    // ─────────────────────────────────────────────────────
    private void spawnRegalithGolem(Location loc) {
        IronGolem golem = (IronGolem) loc.getWorld().spawnEntity(loc, EntityType.IRON_GOLEM);
        golem.setCustomName("§6[Golem de Regolithe]");
        golem.setCustomNameVisible(true);
        golem.setPlayerCreated(false); // Hostile

        if (golem.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null) {
            golem.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(150.0);
            golem.setHealth(150.0);
        }
        if (golem.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE) != null) {
            golem.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE).setBaseValue(18.0);
        }
        if (golem.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED) != null) {
            golem.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED).setBaseValue(0.18); // Lent mais lourd
        }

        golem.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 1, false, false));
        golem.setGlowing(true);

        // Tremblements du sol à proximité (particules)
        startGolemAura(golem);
    }

    /** Aura de particules autour du Golem */
    private void startGolemAura(IronGolem golem) {
        new BukkitRunnable() {
            @Override
            public void run() {
                if (golem.isDead() || !golem.isValid()) { cancel(); return; }
                golem.getWorld().spawnParticle(
                    Particle.BLOCK_CRACK,
                    golem.getLocation().add(0, 1, 0),
                    15, 0.5, 0.5, 0.5, 0.1,
                    Material.END_STONE.createBlockData()
                );
            }
        }.runTaskTimer(plugin, 0L, 10L);
    }

    // ─────────────────────────────────────────────────────
    //  MOB 4 : COSMONAUTE CORROMPU (Zombie)
    // ─────────────────────────────────────────────────────
    private void spawnCorruptedCosmonaut(Location loc) {
        Zombie zombie = (Zombie) loc.getWorld().spawnEntity(loc, EntityType.ZOMBIE);
        zombie.setCustomName("§7[Cosmonaute Corrompu]");
        zombie.setCustomNameVisible(true);
        zombie.setShouldBurnInDay(false); // Pas de brûlure (pas d'atmosphère)
        zombie.setBaby(false);

        if (zombie.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null) {
            zombie.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(25.0);
            zombie.setHealth(25.0);
        }
        if (zombie.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED) != null) {
            zombie.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED).setBaseValue(0.28);
        }

        // Équipement : casque symbolique (fer) + armure partielle
        EntityEquipment eq = zombie.getEquipment();
        if (eq != null) {
            eq.setHelmet(new ItemStack(Material.IRON_HELMET));
            eq.setHelmetDropChance(0.05f);
            if (rand.nextDouble() < 0.3) {
                eq.setChestplate(new ItemStack(Material.CHAINMAIL_CHESTPLATE));
                eq.setChestplateDropChance(0.05f);
            }
        }

        // Résistance au feu (combinaison spatiale)
        zombie.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, false, false));
        zombie.setGlowing(true);
    }
}
