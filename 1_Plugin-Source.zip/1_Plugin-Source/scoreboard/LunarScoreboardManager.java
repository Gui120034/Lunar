package fr.lunar.survival.scoreboard;

import fr.lunar.survival.LunarSurvival;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.*;

import java.util.*;

/**
 * Scoreboard latéral — compatible Java + Bedrock.
 *
 * Fixes Bedrock v2 :
 *  - registerNewObjective() : utilise Component comme displayName (Paper 1.20 API)
 *    au lieu de la String deprecated → rendu couleur correct sur Bedrock
 *  - Entrées du scoreboard : on utilise des Teams avec prefix/suffix Adventure
 *    pour afficher les couleurs. Sans Teams, les §-codes dans les entrées
 *    sont bien supportés par Geyser, mais on renforce avec Component.
 *  - Chaque ligne est une entrée unique avec un score décroissant.
 *
 * Geyser traduit le scoreboard Java en paquet BedrockSetDisplayObjective
 * et BedrockSetScore — les couleurs des entries sont préservées.
 */
public class LunarScoreboardManager {

    private final LunarSurvival plugin;

    private final Map<UUID, Integer> mobsKilled   = new HashMap<>();
    private final Map<UUID, Integer> meteorsLived = new HashMap<>();
    private final Map<UUID, Scoreboard>  boards     = new HashMap<>();
    private final Map<UUID, Objective>   objectives = new HashMap<>();

    // Entrées fixes (espaces invisibles pour unicité)
    private static final String[] KEYS = {
        "§r§0§r", "§r§1§r", "§r§2§r", "§r§3§r", "§r§4§r",
        "§r§5§r", "§r§6§r", "§r§7§r", "§r§8§r", "§r§9§r",
        "§r§a§r", "§r§b§r", "§r§c§r", "§r§d§r"
    };

    public LunarScoreboardManager(LunarSurvival plugin) {
        this.plugin = plugin;
    }

    public void startTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    if (plugin.getOxygenManager().isOnMoon(player)) {
                        updateScoreboard(player);
                    } else {
                        removeScoreboard(player);
                    }
                }
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    private void updateScoreboard(Player player) {
        UUID id = player.getUniqueId();
        if (!boards.containsKey(id)) createScoreboard(player);

        Objective obj = objectives.get(id);
        Scoreboard sb  = boards.get(id);
        if (obj == null || sb == null) return;

        int day    = plugin.getDayManager().getDay(player);
        int o2     = plugin.getOxygenManager().getOxygen(id);
        int kills  = mobsKilled.getOrDefault(id, 0);
        int events = meteorsLived.getOrDefault(id, 0);
        int left   = Math.max(0, 50 - day);

        // Couleurs selon état
        String dayColor = day <= 10 ? "§a" : day <= 30 ? "§e" : day <= 45 ? "§c" : "§d";
        String o2Color  = o2 > 60   ? "§b" : o2 > 30   ? "§e" : "§c";
        String o2Status = o2 > 60   ? "§aSain" : o2 > 30 ? "§eAlerte" : "§cCritique";

        // Vérification si dans station
        boolean inStation = plugin.getSpaceStationManager() != null
                         && plugin.getSpaceStationManager().isInsideStation(player);

        // Lignes dans l'ordre (index 13 = haut, 0 = bas)
        String[] lines = {
            "§f§lLUNAR SURVIVAL",
            "§8--------------",
            " ",
            "§7Jour  " + dayColor + day + " §7/ 50",
            "§7Reste " + dayColor + left + " jours",
            "  ",
            "§7O2    " + o2Color + o2 + "%",
            "§7Etat  " + o2Status,
            "   ",
            inStation ? "§b> STATION SURE" : "§7> En surface",
            "§7Mobs  §f" + kills,
            "§7Meteo §f" + events,
            "    ",
            "§8--------------"
        };

        // Mise à jour des Teams pour chaque ligne (Teams permettent les couleurs via Adventure)
        for (int i = 0; i < lines.length && i < KEYS.length; i++) {
            String key = KEYS[i];
            Team team = sb.getTeam("line" + i);
            if (team == null) {
                team = sb.registerNewTeam("line" + i);
                team.addEntry(key);
                obj.getScore(key).setScore(lines.length - i);
            }
            // prefix = le contenu de la ligne, via Adventure Component
            team.prefix(LegacyComponentSerializer.legacySection().deserialize(lines[i]));
            team.suffix(Component.empty());
        }
    }

    private void createScoreboard(Player player) {
        UUID id = player.getUniqueId();
        ScoreboardManager sbManager = Bukkit.getScoreboardManager();
        if (sbManager == null) return;

        Scoreboard sb = sbManager.getNewScoreboard();

        // Adventure Component pour le titre — compatible Paper 1.20 + Bedrock via Geyser
        Component title = LegacyComponentSerializer.legacySection()
            .deserialize("§b§lLunarSurvival");

        Objective obj = sb.registerNewObjective("lunar", Criteria.DUMMY, title);
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);

        // Enregistrer les entrées fixes une seule fois
        for (int i = 0; i < KEYS.length; i++) {
            Team team = sb.registerNewTeam("line" + i);
            team.addEntry(KEYS[i]);
            obj.getScore(KEYS[i]).setScore(KEYS.length - i);
        }

        boards.put(id, sb);
        objectives.put(id, obj);
        player.setScoreboard(sb);
    }

    private void removeScoreboard(Player player) {
        UUID id = player.getUniqueId();
        if (!boards.containsKey(id)) return;
        ScoreboardManager sbManager = Bukkit.getScoreboardManager();
        if (sbManager != null) player.setScoreboard(sbManager.getMainScoreboard());
        boards.remove(id);
        objectives.remove(id);
    }

    public void incrementKills(UUID id)   { mobsKilled.merge(id, 1, Integer::sum); }
    public void incrementMeteors(UUID id) { meteorsLived.merge(id, 1, Integer::sum); }
    public int  getKills(UUID id)         { return mobsKilled.getOrDefault(id, 0); }
    public int  getMeteors(UUID id)       { return meteorsLived.getOrDefault(id, 0); }
}
