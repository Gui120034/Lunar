package fr.lunar.survival.station;

import fr.lunar.survival.LunarSurvival;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.block.sign.Side;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Station spatiale — base de survie lunaire.
 * Construite automatiquement au spawn du monde lunaire.
 *
 * Fixes Bedrock v2 :
 *  - Panneaux : Sign.line(side, index, Component) au lieu de setLine(String)
 *    → Les couleurs s'affichent correctement côté Bedrock via Geyser
 *  - Tous les textes passent par LegacyComponentSerializer pour rester
 *    cohérents avec le reste du code (§-codes → Component)
 */
public class SpaceStationManager {

    private final LunarSurvival plugin;

    private static final int OFFSET_X   = -7;
    private static final int OFFSET_Z   = -7;
    private static final int FLOOR_OFFSET = 1;
    private static final int W = 15;
    private static final int D = 15;
    private static final int H = 5;

    private Location stationMin;
    private Location stationMax;
    private boolean built = false;

    public SpaceStationManager(LunarSurvival plugin) {
        this.plugin = plugin;
    }

    public void buildStation() {
        World moon = plugin.getLunarWorldManager().getMoonWorld();
        if (moon == null) return;

        Location spawn = moon.getSpawnLocation();
        int bx = spawn.getBlockX() + OFFSET_X;
        int by = moon.getHighestBlockYAt(spawn.getBlockX(), spawn.getBlockZ()) + FLOOR_OFFSET;
        int bz = spawn.getBlockZ() + OFFSET_Z;

        stationMin = new Location(moon, bx,     by,     bz);
        stationMax = new Location(moon, bx + W, by + H, bz + D);
        built = true;

        new BukkitRunnable() {
            int layer = 0;
            @Override
            public void run() {
                if (layer > H + 1) {
                    cancel();
                    placeInterior(moon, bx, by, bz);
                    plugin.getLogger().info("[Station] Construction terminee !");
                    Bukkit.broadcast(
                        LegacyComponentSerializer.legacySection()
                            .deserialize("§b[Station] La station spatiale est prete au spawn !")
                    );
                    return;
                }
                buildLayer(moon, bx, by, bz, layer);
                layer++;
            }
        }.runTaskTimer(plugin, 20L, 2L);
    }

    private void buildLayer(World w, int bx, int by, int bz, int ly) {
        int y = by + ly;
        for (int x = bx; x < bx + W; x++) {
            for (int z = bz; z < bz + D; z++) {
                boolean isWall  = x == bx || x == bx + W - 1 || z == bz || z == bz + D - 1;
                boolean isFloor = ly == 0;
                boolean isRoof  = ly == H;

                if (isFloor) {
                    w.getBlockAt(x, y, z).setType(Material.SMOOTH_STONE);
                } else if (isRoof) {
                    boolean isLantern = (x - bx) % 4 == 2 && (z - bz) % 4 == 2;
                    w.getBlockAt(x, y, z).setType(isLantern ? Material.SEA_LANTERN : Material.IRON_BLOCK);
                } else if (isWall) {
                    boolean isWindow = ly == 2 && !isCorner(x, z, bx, bz)
                                    && ((x - bx) % 3 == 1 || (z - bz) % 3 == 1);
                    w.getBlockAt(x, y, z).setType(isWindow ? Material.GLASS_PANE : Material.IRON_BLOCK);
                } else {
                    w.getBlockAt(x, y, z).setType(Material.AIR);
                }
            }
        }
        // Sas d'entrée
        if (ly == 1 || ly == 2) {
            int doorX = bx + W / 2;
            int doorZ = bz + D - 1;
            w.getBlockAt(doorX - 1, y, doorZ).setType(Material.AIR);
            w.getBlockAt(doorX,     y, doorZ).setType(Material.AIR);
            w.getBlockAt(doorX + 1, y, doorZ).setType(Material.AIR);
        }
    }

    private boolean isCorner(int x, int z, int bx, int bz) {
        return (x == bx || x == bx + W - 1) && (z == bz || z == bz + D - 1);
    }

    private void placeInterior(World w, int bx, int by, int bz) {
        int floorY = by + 1;

        // Dortoir
        for (int i = 0; i < 3; i++) {
            w.getBlockAt(bx + 1, floorY, bz + 1 + i * 2).setType(Material.RED_BED);
            w.getBlockAt(bx + 2, floorY, bz + 1 + i * 2).setType(Material.RED_BED);
        }
        w.getBlockAt(bx + 1, floorY, bz + 7).setType(Material.CHEST);
        w.getBlockAt(bx + 2, floorY, bz + 7).setType(Material.CHEST);
        w.getBlockAt(bx + 3, floorY, bz + 7).setType(Material.CHEST);

        // Atelier
        w.getBlockAt(bx + W - 3, floorY, bz + 1).setType(Material.CRAFTING_TABLE);
        w.getBlockAt(bx + W - 4, floorY, bz + 1).setType(Material.CRAFTING_TABLE);
        w.getBlockAt(bx + W - 2, floorY, bz + 2).setType(Material.ANVIL);
        w.getBlockAt(bx + W - 3, floorY, bz + 2).setType(Material.GRINDSTONE);
        w.getBlockAt(bx + W - 4, floorY, bz + 2).setType(Material.SMITHING_TABLE);
        w.getBlockAt(bx + W - 2, floorY, bz + 4).setType(Material.FURNACE);
        w.getBlockAt(bx + W - 3, floorY, bz + 4).setType(Material.BLAST_FURNACE);
        w.getBlockAt(bx + W - 4, floorY, bz + 4).setType(Material.SMOKER);

        // Serre
        for (int x = bx + W - 6; x < bx + W - 2; x++) {
            for (int z2 = bz + D - 6; z2 < bz + D - 2; z2++) {
                w.getBlockAt(x, by,         z2).setType(Material.WATER);
                w.getBlockAt(x, floorY - 1, z2).setType(Material.FARMLAND);
                w.getBlockAt(x, floorY,     z2).setType(Material.WHEAT);
            }
        }
        w.getBlockAt(bx + W - 4, by + H - 1, bz + D - 4).setType(Material.GLOWSTONE);

        // Éclairage sol
        w.getBlockAt(bx + 4,     floorY - 1, bz + 4    ).setType(Material.SEA_LANTERN);
        w.getBlockAt(bx + W - 5, floorY - 1, bz + 4    ).setType(Material.SEA_LANTERN);
        w.getBlockAt(bx + 4,     floorY - 1, bz + D - 5).setType(Material.SEA_LANTERN);
        w.getBlockAt(bx + W - 5, floorY - 1, bz + D - 5).setType(Material.SEA_LANTERN);

        // ── Panneaux via Adventure API — couleurs identiques Java + Bedrock ──
        placeWallSign(w, bx + 1, by + 3, bz + D / 2,
            comp("§b== STATION =="),
            comp("§aZONE SURE"),
            comp("§7O2 : NORMAL"),
            comp("§7Casque optionnel")
        );
        placeWallSign(w, bx + W - 2, by + 3, bz + D / 2,
            comp("§e== ATELIER =="),
            comp("§7Tables de craft"),
            comp("§7Four / Enclume"),
            comp("§7Smither / Grind")
        );

        // Tourelles
        buildTurret(w, bx - 1, by, bz - 1);
        buildTurret(w, bx + W, by, bz - 1);
        buildTurret(w, bx - 1, by, bz + D);
        buildTurret(w, bx + W, by, bz + D);
    }

    private void buildTurret(World w, int x, int by, int z) {
        for (int dy = 0; dy < 4; dy++) w.getBlockAt(x, by + dy, z).setType(Material.IRON_BARS);
        w.getBlockAt(x, by + 4, z).setType(Material.SEA_LANTERN);
    }

    /**
     * Place un panneau mural avec texte coloré via Adventure API.
     * Sign.line(Side, index, Component) → supporté par Geyser → couleurs visibles Bedrock.
     * Contrairement à sign.setLine(String) qui strip les §-codes côté Bedrock.
     */
    private void placeWallSign(World w, int x, int y, int z,
                                Component l0, Component l1, Component l2, Component l3) {
        Block b = w.getBlockAt(x, y, z);
        b.setType(Material.OAK_WALL_SIGN);
        if (b.getState() instanceof Sign sign) {
            sign.line(0, l0);
            sign.line(1, l1);
            sign.line(2, l2);
            sign.line(3, l3);
            sign.update();
        }
    }

    /** Convertit un §-code legacy en Component Adventure */
    private Component comp(String legacy) {
        return LegacyComponentSerializer.legacySection().deserialize(legacy);
    }

    public boolean isInsideStation(Player player) {
        if (!built || stationMin == null) return false;
        if (!player.getWorld().getName().equals(
                plugin.getLunarWorldManager().getMoonWorldName())) return false;
        Location loc = player.getLocation();
        return loc.getX() >= stationMin.getX() && loc.getX() <= stationMax.getX()
            && loc.getY() >= stationMin.getY() && loc.getY() <= stationMax.getY()
            && loc.getZ() >= stationMin.getZ() && loc.getZ() <= stationMax.getZ();
    }

    public boolean isBuilt() { return built; }

    public void teleportToStation(Player player) {
        if (!built || stationMin == null) {
            player.sendMessage("§c[Station] La station n'est pas encore construite !");
            return;
        }
        World moon = plugin.getLunarWorldManager().getMoonWorld();
        if (moon == null) return;
        Location entry = stationMin.clone().add(W / 2.0, 1, D - 2.0);
        player.teleport(entry);
        player.sendMessage("§b[Station] Teleporte a l'entree de la station.");
    }
}
