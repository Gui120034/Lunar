package fr.lunar.survival.station;

import fr.lunar.survival.BedrockCompat;
import fr.lunar.survival.LunarSurvival;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Gère les effets quand un joueur entre/sort de la station spatiale.
 *
 *  DANS la station :
 *   - O2 NON drainé (même sans casque) → overridé dans OxygenManager
 *   - Gravité NORMALE (Slow Falling retiré) — on est dans une station pressurisée
 *   - Effets asphyxie retirés immédiatement
 *   - Titre de bienvenue à l'entrée
 *   - Particules légères de "circulation d'air" pour l'ambiance
 *
 *  HORS de la station :
 *   - Gravité lunaire réactivée
 *   - O2 recommence à baisser si sans casque
 *   - Titre d'avertissement à la sortie
 */
public class StationZoneListener implements Listener {

    private final LunarSurvival plugin;

    // Joueurs actuellement dans la station (pour détecter entrée/sortie)
    private final Set<UUID> insideStation = new HashSet<>();

    public StationZoneListener(LunarSurvival plugin) {
        this.plugin = plugin;
        startAmbientTask();
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getOxygenManager().isOnMoon(player)) return;

        UUID id = player.getUniqueId();
        boolean wasInside = insideStation.contains(id);
        boolean isInside  = plugin.getSpaceStationManager().isInsideStation(player);

        if (isInside && !wasInside) {
            // ── ENTRÉE dans la station ────────────────────────────────
            insideStation.add(id);
            onEnterStation(player);

        } else if (!isInside && wasInside) {
            // ── SORTIE de la station ──────────────────────────────────
            insideStation.remove(id);
            onExitStation(player);
        }
    }

    private void onEnterStation(Player player) {
        // Retirer les effets lunaires (gravité)
        player.removePotionEffect(PotionEffectType.SLOW_FALLING);
        player.removePotionEffect(PotionEffectType.JUMP_BOOST);
        // Retirer l'asphyxie si elle était active
        player.removePotionEffect(PotionEffectType.BLINDNESS);
        player.removePotionEffect(PotionEffectType.SLOWNESS);
        player.removePotionEffect(PotionEffectType.WEAKNESS);

        // Régénération légère à l'intérieur
        player.addPotionEffect(new PotionEffect(
            PotionEffectType.REGENERATION, 20 * 10, 0, false, false));

        // Titre d'entrée via Adventure API — compatible Java + Bedrock
        BedrockCompat.sendTitle(player,
            "§b[Station Spatiale]",
            "§aZone pressurisee. Vous pouvez respirer.",
            5, 50, 15
        );
        player.playSound(player.getLocation(), Sound.BLOCK_IRON_DOOR_OPEN, 1f, 1f);
        player.sendMessage("§b[Station] §aZone sure — O2 stabilise. Casque non obligatoire ici.");

        // Recharger l'O2 rapidement à l'entrée
        int currentO2 = plugin.getOxygenManager().getOxygen(player.getUniqueId());
        if (currentO2 < 100) {
            // Recharge progressive sur 5 secondes
            new BukkitRunnable() {
                int ticks = 0;
                @Override
                public void run() {
                    if (ticks++ > 10 || !plugin.getSpaceStationManager().isInsideStation(player)) {
                        cancel(); return;
                    }
                    int o2 = plugin.getOxygenManager().getOxygen(player.getUniqueId());
                    plugin.getOxygenManager().setOxygen(player.getUniqueId(), Math.min(100, o2 + 10));
                }
            }.runTaskTimer(plugin, 10L, 10L);
        }
    }

    private void onExitStation(Player player) {
        // Réactiver la gravité lunaire
        plugin.getGravityManager().applyLunarGravity(player);

        BedrockCompat.sendTitle(player,
            "§c[Sortie Station]",
            "§7Verifiez votre casque avant de sortir !",
            5, 40, 15
        );
        player.playSound(player.getLocation(), Sound.BLOCK_IRON_DOOR_CLOSE, 1f, 0.8f);
        player.sendMessage("§c[Station] Vous quittez la zone sure. Casque obligatoire !");
    }

    /** Vérifie si un joueur est dans la station (pour OxygenManager) */
    public boolean isInStation(UUID id) {
        return insideStation.contains(id);
    }

    /** Particules d'ambiance dans la station — circulation d'air */
    private void startAmbientTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (UUID id : insideStation) {
                    Player player = plugin.getServer().getPlayer(id);
                    if (player == null || !player.isOnline()) continue;

                    // Légère particule "air" autour du joueur (subtil)
                    player.getWorld().spawnParticle(
                        Particle.SPELL_INSTANT,
                        player.getLocation().add(0, 1.5, 0),
                        2, 0.4, 0.3, 0.4, 0.01
                    );
                }
            }
        }.runTaskTimer(plugin, 40L, 40L); // Toutes les 2 secondes
    }
}
