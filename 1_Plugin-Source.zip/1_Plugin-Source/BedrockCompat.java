package fr.lunar.survival;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import net.kyori.adventure.title.TitlePart;
import org.bukkit.entity.Player;

import java.time.Duration;

/**
 * ============================================================
 *   BedrockCompat — Couche de compatibilité Java + Bedrock
 * ============================================================
 *
 *  Problèmes Bedrock via Geyser :
 *
 *  1. ACTION BAR
 *     - player.spigot().sendMessage(ChatMessageType.ACTION_BAR) → cassé sous Geyser
 *     - Fix : player.sendActionBar(Component) — API Adventure (Paper), fonctionne partout
 *
 *  2. TITRES
 *     - player.sendTitle(String, String, in, int, int) → deprecated + mal traduit Bedrock
 *     - Fix : player.showTitle(Title) — API Adventure, rendu identique Java/Bedrock
 *
 *  3. CARACTÈRES UNICODE
 *     - Bedrock ne rend pas : █ ☀ ☄ ✦ ★ ✖ ✓ ▶ 🌙 🧪 🪐 💎 O₂
 *     - Fix : on utilise des alternatives ASCII+section que les deux plateformes supportent
 *       █ → |       ☀ → *       ☄ → ~       ✦ → *
 *       ★ → *       ✖ → X       ✓ → V       ▶ → >
 *       🌙 → (lune) → on garde le texte     O₂ → O2
 *
 *  4. SONS
 *     - Certains sons Java (UI_TOAST_CHALLENGE_COMPLETE, ENTITY_ELDER_GUARDIAN_CURSE)
 *       ne sont pas mappés par Geyser → silencieux côté Bedrock
 *     - Fix : on utilise uniquement des sons mappés dans la table Geyser :
 *       https://github.com/GeyserMC/Geyser/blob/master/core/src/main/resources/bedrock/sound_mappings.json
 *       Sons sûrs : ENTITY_PLAYER_LEVELUP, ENTITY_EXPERIENCE_ORB_PICKUP,
 *                   BLOCK_NOTE_BLOCK_BASS, ENTITY_GENERIC_EXPLODE,
 *                   ENTITY_CREEPER_HURT, ENTITY_VILLAGER_NO, AMBIENT_CAVE
 *
 *  5. PARTICULES
 *     - SMOKE_NORMAL → renommé SMOKE en 1.20.5+ ; FALLING_DUST → BLOCK_DUST
 *     - Fix : on centralise les particules ici pour un seul point de maintenance
 *
 *  6. ITEMS NOMMÉS
 *     - Les noms d'items avec émojis (🌙 🧪) s'affichent en carré Bedrock
 *     - Fix : noms sans émojis, avec couleur uniquement
 */
public final class BedrockCompat {

    private BedrockCompat() {}

    // ─────────────────────────────────────────
    //  ACTION BAR (identique Java + Bedrock)
    // ─────────────────────────────────────────

    /**
     * Envoie un message dans l'action bar — fonctionne Java ET Bedrock via Geyser.
     * Utilise l'API Adventure (Paper 1.18+) qui est correctement relayée par Geyser.
     */
    public static void sendActionBar(Player player, String legacyText) {
        Component component = LegacyComponentSerializer.legacySection().deserialize(legacyText);
        player.sendActionBar(component);
    }

    // ─────────────────────────────────────────
    //  TITRES (identique Java + Bedrock)
    // ─────────────────────────────────────────

    /**
     * Affiche un titre — fonctionne Java ET Bedrock via Geyser.
     * L'API Adventure Title est correctement traduite par Geyser en paquet Bedrock SetTitle.
     *
     * @param fadeIn   ticks
     * @param stay     ticks
     * @param fadeOut  ticks
     */
    public static void sendTitle(Player player, String title, String subtitle,
                                  int fadeIn, int stay, int fadeOut) {
        Title.Times times = Title.Times.times(
            Duration.ofMillis(fadeIn  * 50L),
            Duration.ofMillis(stay    * 50L),
            Duration.ofMillis(fadeOut * 50L)
        );
        Title adventureTitle = Title.title(
            LegacyComponentSerializer.legacySection().deserialize(title),
            LegacyComponentSerializer.legacySection().deserialize(subtitle),
            times
        );
        player.showTitle(adventureTitle);
    }

    // ─────────────────────────────────────────
    //  TEXTE COMPATIBLE (sans emojis/glyphes)
    // ─────────────────────────────────────────

    /** Barre d'action speciale quand le joueur est dans la station spatiale */
    public static String buildStationBar(int oxygen, int day) {
        return "§a[||||||||||] 100%§7 O2  §b** STATION **  §e* Jour §f" + day + "§7/50";
    }

    /**
     * Barre d'oxygène — version compatible Java + Bedrock.
     * On remplace █ par | qui est ASCII de base, rendu identique sur les deux.
     *
     * Java   : §b[||||||||||] 100% O2   §e* Jour §f1§7/50
     * Bedrock: rendu identique via Geyser
     */
    public static String buildOxygenBar(int oxygen, int day) {
        int filled = oxygen / 10;
        String color;
        if      (oxygen > 60) color = "§b";
        else if (oxygen > 30) color = "§e";
        else                   color = "§c";

        StringBuilder bar = new StringBuilder("§7[");
        for (int i = 0; i < 10; i++) {
            bar.append(i < filled ? color + "|" : "§8|");
        }
        bar.append("§7] ")
           .append(color).append(oxygen).append("%")
           .append(" §7O2")
           .append("   §e* §eJour §f").append(day).append("§7/50");
        return bar.toString();
    }

    // ─────────────────────────────────────────
    //  NOMS D'ITEMS COMPATIBLES
    // ─────────────────────────────────────────
    //  (sans émojis — Bedrock affiche des carrés pour les émojis)

    public static final String ITEM_HELMET_NAME      = "§b[Casque Spatial Mk.I]";
    public static final String ITEM_HELMET_LORE1     = "§7Filtre l'air de votre reserve d'oxygene.";
    public static final String ITEM_HELMET_LORE2     = "§cNe le retirez JAMAIS sur la Lune !";

    public static final String ITEM_OXY_TANK_NAME    = "§b[Reserve d'Oxygene]";
    public static final String ITEM_OXY_TANK_LORE1   = "§7Pour survivre sur la Lune.";
    public static final String ITEM_OXY_TANK_LORE2   = "§eConsommable (Usage futur)";

    public static final String ITEM_HELMET_SPARE     = "§b[Casque de Secours]";
    public static final String ITEM_DIAMOND_LUNAR    = "§b[Diamant Lunaire]";
    public static final String ITEM_FOOD_RATION      = "§e[Ration Spatiale]";
    public static final String ITEM_IRON_ALLOY       = "§7[Alliage Lunaire]";
    public static final String ITEM_GOLD_METEOR      = "§6[Or de Meteorite]";
    public static final String ITEM_TORCH_SPACE      = "§e[Flambeau Spatial]";
    public static final String ITEM_TNT_CHARGE       = "§c[Charge Explosive]";
    public static final String ITEM_PEARL_QUANTUM    = "§d[Perle Quantique]";
    public static final String ITEM_METEOR_FRAGMENT  = "§d[Fragment Lunaire]";

    // ─────────────────────────────────────────
    //  TEXTES DE TITRES / MESSAGES (sans emojis)
    // ─────────────────────────────────────────

    // Bienvenue sur la Lune
    public static final String TITLE_WELCOME        = "§f** Bienvenue sur la Lune **";
    public static final String TITLE_WELCOME_SUB    = "§7Survivez §e50 jours§7. Il n'y a pas de retour.";

    // Nouveau jour
    public static String titleDay(String color, int day) {
        return color + "* Jour " + day + " / 50 *";
    }

    // Victoire
    public static final String TITLE_VICTORY        = "§6§l** VICTOIRE **";
    public static final String TITLE_VICTORY_SUB    = "§f50 jours accomplis ! Vous etes une legende.";

    // Casque retiré
    public static final String TITLE_NO_HELMET      = "§4§lX EXPOSITION AU VIDE";
    public static final String TITLE_NO_HELMET_SUB  = "§cRemettez votre casque !";

    // Casque remis
    public static final String TITLE_HELMET_OK      = "§aV Casque detecte";
    public static final String TITLE_HELMET_OK_SUB  = "§7Oxygene en cours de recharge...";

    // Portail bloqué
    public static final String MSG_PORTAL_BLOCKED   = "§cX Impossible de quitter la Lune avant 50 jours !";
    public static final String MSG_PORTAL_BLOCKED2  = "§cLa Lune vous retient encore...";

    // Météorite
    public static final String MSG_METEOR_WARNING   = "§c~ Une meteorite approche ! Cherchez un abri !";
    public static final String MSG_METEOR_IMPACT    = "§c~ IMPACT ! Choc de la meteorite !";

    // Casque retiré
    public static final String MSG_HELMET_REMOVED   = "§cX CASQUE RETIRE ! Remettez-le immediatement !";

    // Broadcast victoire
    public static String broadcastVictory(String name) {
        return "§6§l[LUNAR] §f" + name + " §ea survecu §650 jours sur la Lune !";
    }

    // Messages milestones
    public static final String MILESTONE_10 = "§a> 10 jours ! Vous etes taille pour ca.";
    public static final String MILESTONE_25 = "§e> Mi-chemin ! 25 jours sur la Lune !";
    public static final String MILESTONE_40 = "§c> 40 jours ! Les etoiles vous appellent...";
    public static final String MILESTONE_49 = "§d> DEMAIN C'EST FINI ! Tenez bon !";

    // Welcome messages
    public static final String MSG_WELCOME_LINE  = "§7----------------------------------";
    public static final String MSG_WELCOME_1     = "  §e~ Bienvenue, survivant(e) !";
    public static final String MSG_WELCOME_2     = "  §7* Gardez votre §bcasque§7 en permanence";
    public static final String MSG_WELCOME_3     = "  §7* Evitez les §cmeteoorites§7";
    public static final String MSG_WELCOME_4     = "  §7* 50 jours lunaires §7(x20 min) a tenir";
    public static final String MSG_WELCOME_5     = "  §7* L'Overworld est §cinaccessible";

    // Separator
    public static final String SEP = "§7------------------------------";
}
