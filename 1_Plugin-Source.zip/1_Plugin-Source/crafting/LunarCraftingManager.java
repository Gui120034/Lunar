package fr.lunar.survival.crafting;

import fr.lunar.survival.LunarSurvival;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.NamespacedKey;

import java.util.Arrays;

/**
 * Recettes de craft spatiales — exclusives à la Lune.
 *
 * Recettes ajoutées :
 *
 *  [1] CASQUE SPATIAL MK.II
 *      Diamond Helmet + 4 Phantom Membrane + 4 Iron Ingot
 *      → Meilleur casque, pas de perte d'O2 pendant 10s si retiré
 *
 *  [2] COMBINAISON SPATIALE (Chestplate)
 *      Iron Chestplate + 4 Leather + 4 Quartz
 *      → Resistance I permanent sur la Lune
 *
 *  [3] BOTTES LUNAIRES
 *      Iron Boots + 2 Feather + 2 Phantom Membrane
 *      → Feather Falling V + Jump III intégré (en plus de la gravité du plugin)
 *
 *  [4] SCANNER LUNAIRE (Compass modifié)
 *      Compass + 4 Quartz + 4 Gold Ingot
 *      → Indique la direction du spawn lunaire
 *
 *  [5] BOMBE A REGOLITHE (TNT améliorée)
 *      TNT + 4 End Stone + 4 Gunpowder
 *      → Explosion plus puissante, creuse les cratères
 *
 *  [6] KIT DE REPARATION D'OXYGENE
 *      3 Glass Bottle + 3 Iron Ingot + 3 Phantom Membrane
 *      → Restore immédiatement 50% d'O2 (item consommable)
 */
public class LunarCraftingManager implements Listener {

    private final LunarSurvival plugin;

    public LunarCraftingManager(LunarSurvival plugin) {
        this.plugin = plugin;
    }

    public void registerRecipes() {
        registerHelmetMk2();
        registerSpaceSuit();
        registerLunarBoots();
        registerOxygenKit();
        registerLunarBomb();
        plugin.getLogger().info("[Crafting] 5 recettes spatiales enregistrees.");
    }

    // ─── [1] CASQUE SPATIAL MK.II ────────────────────────────────────
    private void registerHelmetMk2() {
        NamespacedKey key = new NamespacedKey(plugin, "space_helmet_mk2");
        ShapedRecipe recipe = new ShapedRecipe(key, buildHelmetMk2());
        recipe.shape(
            "MMM",
            "MDM",
            "IMI"
        );
        recipe.setIngredient('M', Material.PHANTOM_MEMBRANE);
        recipe.setIngredient('D', Material.DIAMOND_HELMET);
        recipe.setIngredient('I', Material.IRON_INGOT);
        Bukkit.addRecipe(recipe);
    }

    private ItemStack buildHelmetMk2() {
        ItemStack item = new ItemStack(Material.DIAMOND_HELMET);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§b[Casque Spatial Mk.II]");
        meta.setLore(Arrays.asList(
            "§7Filtre renforce. Survit 10s sans oxygene.",
            "§7Craft exclusif sur la Lune.",
            "§eTechnologie avancee spatiale."
        ));
        // Enchantement : Protection IV + Respiration III
        item.addUnsafeEnchantment(org.bukkit.enchantments.Enchantment.PROTECTION, 4);
        item.addUnsafeEnchantment(org.bukkit.enchantments.Enchantment.RESPIRATION, 3);
        item.setItemMeta(meta);
        return item;
    }

    // ─── [2] COMBINAISON SPATIALE ────────────────────────────────────
    private void registerSpaceSuit() {
        NamespacedKey key = new NamespacedKey(plugin, "space_suit");
        ShapedRecipe recipe = new ShapedRecipe(key, buildSpaceSuit());
        recipe.shape(
            "LIL",
            "QCQ",
            "LIL"
        );
        recipe.setIngredient('L', Material.LEATHER);
        recipe.setIngredient('I', Material.IRON_INGOT);
        recipe.setIngredient('Q', Material.QUARTZ);
        recipe.setIngredient('C', Material.IRON_CHESTPLATE);
        Bukkit.addRecipe(recipe);
    }

    private ItemStack buildSpaceSuit() {
        ItemStack item = new ItemStack(Material.DIAMOND_CHESTPLATE);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§b[Combinaison Spatiale]");
        meta.setLore(Arrays.asList(
            "§7Resistance I permanente sur la Lune.",
            "§7Craft exclusif sur la Lune.",
            "§ePoids reduit en apesanteur."
        ));
        item.addUnsafeEnchantment(org.bukkit.enchantments.Enchantment.PROTECTION, 3);
        item.setItemMeta(meta);
        return item;
    }

    // ─── [3] BOTTES LUNAIRES ─────────────────────────────────────────
    private void registerLunarBoots() {
        NamespacedKey key = new NamespacedKey(plugin, "lunar_boots");
        ShapedRecipe recipe = new ShapedRecipe(key, buildLunarBoots());
        recipe.shape(
            "FMF",
            "IBI",
            "   "
        );
        recipe.setIngredient('F', Material.FEATHER);
        recipe.setIngredient('M', Material.PHANTOM_MEMBRANE);
        recipe.setIngredient('I', Material.IRON_INGOT);
        recipe.setIngredient('B', Material.IRON_BOOTS);
        Bukkit.addRecipe(recipe);
    }

    private ItemStack buildLunarBoots() {
        ItemStack item = new ItemStack(Material.DIAMOND_BOOTS);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§b[Bottes Lunaires]");
        meta.setLore(Arrays.asList(
            "§7Feather Falling V + Saut renforce.",
            "§7Parfaites pour la gravite lunaire.",
            "§eCraft exclusif sur la Lune."
        ));
        item.addUnsafeEnchantment(org.bukkit.enchantments.Enchantment.FEATHER_FALLING, 5);
        item.addUnsafeEnchantment(org.bukkit.enchantments.Enchantment.JUMP_BOOST, 3);
        item.setItemMeta(meta);
        return item;
    }

    // ─── [4] KIT DE REPARATION O2 ────────────────────────────────────
    private void registerOxygenKit() {
        NamespacedKey key = new NamespacedKey(plugin, "oxygen_kit");
        ShapedRecipe recipe = new ShapedRecipe(key, buildOxygenKit());
        recipe.shape(
            "GIG",
            "IMI",
            "GIG"
        );
        recipe.setIngredient('G', Material.GLASS_BOTTLE);
        recipe.setIngredient('I', Material.IRON_INGOT);
        recipe.setIngredient('M', Material.PHANTOM_MEMBRANE);
        Bukkit.addRecipe(recipe);
    }

    private ItemStack buildOxygenKit() {
        ItemStack item = new ItemStack(Material.GLASS_BOTTLE);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§b[Kit Reparation O2]");
        meta.setLore(Arrays.asList(
            "§7Clic droit : restaure 50% d'oxygene.",
            "§7Usage unique.",
            "§eCraft exclusif sur la Lune."
        ));
        item.setItemMeta(meta);
        return item;
    }

    // ─── [5] BOMBE A REGOLITHE ───────────────────────────────────────
    private void registerLunarBomb() {
        NamespacedKey key = new NamespacedKey(plugin, "lunar_bomb");
        ShapedRecipe recipe = new ShapedRecipe(key, buildLunarBomb());
        recipe.shape(
            "ESE",
            "STS",
            "ESE"
        );
        recipe.setIngredient('E', Material.END_STONE);
        recipe.setIngredient('S', Material.GUNPOWDER);
        recipe.setIngredient('T', Material.TNT);
        Bukkit.addRecipe(recipe);
    }

    private ItemStack buildLunarBomb() {
        ItemStack item = new ItemStack(Material.TNT);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§c[Bombe a Regolithe]");
        meta.setLore(Arrays.asList(
            "§7Explosion renforcee. Creuse les crateres.",
            "§cDangereux sans abri.",
            "§eCraft exclusif sur la Lune."
        ));
        item.setItemMeta(meta);
        return item;
    }

    // ─── Écoute du craft pour restreindre aux joueurs sur la Lune ────
    @EventHandler
    public void onCraft(CraftItemEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        ItemStack result = event.getRecipe().getResult();
        if (result.getItemMeta() == null) return;
        String name = result.getItemMeta().getDisplayName();

        // Vérifier si c'est un item lunaire exclusif
        boolean isLunarItem = name.contains("Mk.II") || name.contains("Spatiale")
            || name.contains("Lunaires") || name.contains("O2")
            || name.contains("Regolithe");

        if (isLunarItem && !plugin.getOxygenManager().isOnMoon(player)) {
            event.setCancelled(true);
            player.sendMessage("§c[Craft] Cette recette ne fonctionne que sur la Lune !");
        }
    }
}
