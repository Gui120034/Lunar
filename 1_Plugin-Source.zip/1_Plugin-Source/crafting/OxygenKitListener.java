package fr.lunar.survival.crafting;

import fr.lunar.survival.BedrockCompat;
import fr.lunar.survival.LunarSurvival;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class OxygenKitListener implements Listener {

    private final LunarSurvival plugin;

    public OxygenKitListener(LunarSurvival plugin) { this.plugin = plugin; }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getOxygenManager().isOnMoon(player)) return;

        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getType() != Material.GLASS_BOTTLE) return;
        if (item.getItemMeta() == null) return;
        if (!item.getItemMeta().hasDisplayName()) return;
        if (!item.getItemMeta().getDisplayName().contains("Kit Reparation O2")) return;

        // Consommer le kit
        int currentO2 = plugin.getOxygenManager().getOxygen(player.getUniqueId());
        int newO2 = Math.min(100, currentO2 + 50);
        plugin.getOxygenManager().setOxygen(player.getUniqueId(), newO2);

        // Retirer 1 kit de l'inventaire
        item.setAmount(item.getAmount() - 1);

        // Feedback
        BedrockCompat.sendTitle(player,
            "§b[O2 Restaure]",
            "§7+" + (newO2 - currentO2) + "% d'oxygene",
            5, 30, 10
        );
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
        player.sendMessage("§b[O2] Kit utilise ! Oxygene : §f" + newO2 + "%");

        // Particules
        player.getWorld().spawnParticle(
            Particle.SPELL_INSTANT,
            player.getLocation().add(0, 1, 0),
            20, 0.5, 0.5, 0.5, 0.1
        );

        event.setCancelled(true);
    }
}
