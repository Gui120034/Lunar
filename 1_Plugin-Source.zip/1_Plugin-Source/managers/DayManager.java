package fr.lunar.survival.managers;

import fr.lunar.survival.BedrockCompat;
import fr.lunar.survival.LunarSurvival;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class DayManager {

    private final LunarSurvival plugin;
    // 1 jour lunaire = 20 minutes reelles
    private static final long LUNAR_DAY_TICKS = 20L * 60 * 20;
    private static final int  MAX_DAYS        = 50;

    private final Map<UUID, Integer> playerDays    = new HashMap<>();
    private final Map<UUID, Long>    tickCounters  = new HashMap<>();

    public DayManager(LunarSurvival plugin) { this.plugin = plugin; }

    public void startTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    if (!plugin.getOxygenManager().isOnMoon(player)) continue;

                    UUID id = player.getUniqueId();
                    playerDays.putIfAbsent(id, 1);
                    tickCounters.putIfAbsent(id, 0L);

                    long ticks = tickCounters.get(id) + 20L;
                    tickCounters.put(id, ticks);

                    if (ticks >= LUNAR_DAY_TICKS) {
                        tickCounters.put(id, 0L);
                        int newDay = playerDays.get(id) + 1;
                        playerDays.put(id, newDay);
                        onNewDay(player, newDay);
                    }
                }
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    private void onNewDay(Player player, int day) {
        if (day > MAX_DAYS) { triggerVictory(player); return; }

        // Couleurs + sous-titres qui evoluent
        String dayColor; String subtitle; Sound sound;

        if (day <= 10) {
            dayColor = "§a"; subtitle = "§7Vous survivez bien... pour l'instant.";
            sound = Sound.ENTITY_PLAYER_LEVELUP;                // Sur : Java + Bedrock
        } else if (day <= 20) {
            dayColor = "§e"; subtitle = "§7Le silence de la Lune est pesant.";
            sound = Sound.ENTITY_PLAYER_LEVELUP;
        } else if (day <= 35) {
            dayColor = "§6"; subtitle = "§7Vous commencez a oublier la Terre.";
            sound = Sound.ENTITY_EXPERIENCE_ORB_PICKUP;         // Sur : Java + Bedrock
        } else if (day <= 45) {
            dayColor = "§c"; subtitle = "§7La folie lunaire vous guette...";
            sound = Sound.ENTITY_CREEPER_HURT;                  // Sur : Java + Bedrock
        } else {
            dayColor = "§d"; subtitle = "§f* Plus que " + (MAX_DAYS - day + 1) + " jour(s) !";
            sound = Sound.ENTITY_PLAYER_LEVELUP;
        }

        // Titre via Adventure API — identique Java + Bedrock
        BedrockCompat.sendTitle(player,
            BedrockCompat.titleDay(dayColor, day),
            subtitle,
            10, 60, 20
        );
        player.playSound(player.getLocation(), sound, 1f, 1f);

        // Paliers speciaux
        if (day == 10) sendMilestone(player, BedrockCompat.MILESTONE_10);
        if (day == 25) sendMilestone(player, BedrockCompat.MILESTONE_25);
        if (day == 40) {
            sendMilestone(player, BedrockCompat.MILESTONE_40);
            plugin.getMeteorManager().triggerMeteorShower(player, 10);
        }
        if (day == 49) sendMilestone(player, BedrockCompat.MILESTONE_49);
    }

    private void triggerVictory(Player player) {
        // Titre victoire via Adventure API
        BedrockCompat.sendTitle(player,
            BedrockCompat.TITLE_VICTORY,
            BedrockCompat.TITLE_VICTORY_SUB,
            10, 100, 30
        );
        // Sons surs Java + Bedrock
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP,          1f, 1f);
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP,   1f, 1.5f);

        // Broadcast via Adventure API — compatible Java + Bedrock
        Bukkit.broadcast(
            LegacyComponentSerializer.legacySection()
                .deserialize(BedrockCompat.broadcastVictory(player.getName()))
        );
        

        plugin.getLunarWorldManager().openReturnPortal(player);
    }

    private void sendMilestone(Player player, String msg) {
        player.sendMessage(BedrockCompat.SEP);
        player.sendMessage("  " + msg);
        player.sendMessage(BedrockCompat.SEP);
    }

    public int  getDay(Player player)       { return playerDays.getOrDefault(player.getUniqueId(), 1); }
    public void setDay(UUID id, int day)    { playerDays.put(id, day); }
}
