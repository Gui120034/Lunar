package fr.lunar.survival.managers;

import fr.lunar.survival.BedrockCompat;
import fr.lunar.survival.LunarSurvival;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class OxygenManager {

    private final LunarSurvival plugin;
    private final Map<UUID, Integer> oxygenLevels = new HashMap<>();
    private final Map<UUID, Boolean> hadHelmet    = new HashMap<>();

    public OxygenManager(LunarSurvival plugin) {
        this.plugin = plugin;
    }

    public void startTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    if (!isOnMoon(player)) continue;

                    UUID id = player.getUniqueId();
                    oxygenLevels.putIfAbsent(id, 100);

                    boolean hasHelmet   = hasSpaceHelmet(player);
                    boolean inStation   = plugin.getSpaceStationManager() != null
                                      && plugin.getSpaceStationManager().isInsideStation(player);
                    int oxygen = oxygenLevels.get(id);

                    if (inStation) {
                        // DANS LA STATION : O2 se recharge, effets retirés
                        oxygen = Math.min(100, oxygen + 5);
                        removeAsphyxiaEffects(player);

                    } else if (hasHelmet) {
                        oxygen = Math.min(100, oxygen + 3);
                        removeAsphyxiaEffects(player);
                        if (Boolean.FALSE.equals(hadHelmet.get(id))) {
                            BedrockCompat.sendTitle(player,
                                BedrockCompat.TITLE_HELMET_OK,
                                BedrockCompat.TITLE_HELMET_OK_SUB,
                                5, 30, 10);
                        }
                    } else {
                        oxygen = Math.max(0, oxygen - 8);
                        applyAsphyxiaEffects(player, oxygen);
                        // Sons surs Java + Bedrock
                        if (oxygen == 40) player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1f, 0.5f);
                        if (oxygen == 20) player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1f, 0.3f);
                        if (oxygen == 0)  player.damage(3.0);
                    }

                    oxygenLevels.put(id, oxygen);
                    hadHelmet.put(id, inStation || hasHelmet);

                    // ACTION BAR via Adventure API — identique Java + Bedrock
                    String bar = inStation
                        ? BedrockCompat.buildStationBar(oxygen, plugin.getDayManager().getDay(player))
                        : BedrockCompat.buildOxygenBar(oxygen, plugin.getDayManager().getDay(player));
                    BedrockCompat.sendActionBar(player, bar);
                }
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    private void applyAsphyxiaEffects(Player player, int oxygen) {
        if (oxygen <= 60) player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,      40, 0, false, false));
        if (oxygen <= 30) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 0, false, false));
            spawnAsphyxiaParticles(player);
        }
        if (oxygen <= 10) player.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS,  40, 1, false, false));
    }

    private void removeAsphyxiaEffects(Player player) {
        player.removePotionEffect(PotionEffectType.BLINDNESS);
        player.removePotionEffect(PotionEffectType.SLOWNESS);
        player.removePotionEffect(PotionEffectType.WEAKNESS);
    }

    private void spawnAsphyxiaParticles(Player player) {
        // SMOKE_LARGE : stable 1.13-1.20.x, mappe vers levelEvent smoke cote Bedrock
        player.getWorld().spawnParticle(
            Particle.SMOKE_LARGE,
            player.getLocation().add(0, 1.8, 0),
            10, 0.3, 0.3, 0.3, 0.02
        );
    }

    public boolean hasSpaceHelmet(Player player) {
        ItemStack helmet = player.getInventory().getHelmet();
        return helmet != null && helmet.getType() != Material.AIR;
    }

    public boolean isOnMoon(Player player) {
        return player.getWorld().getName().equals(plugin.getLunarWorldManager().getMoonWorldName());
    }

    public void setOxygen(UUID id, int value) { oxygenLevels.put(id, Math.max(0, Math.min(100, value))); }
    public int  getOxygen(UUID id)            { return oxygenLevels.getOrDefault(id, 100); }
}
