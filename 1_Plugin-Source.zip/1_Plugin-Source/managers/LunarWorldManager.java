package fr.lunar.survival.managers;

import fr.lunar.survival.BedrockCompat;
import fr.lunar.survival.LunarSurvival;
import org.bukkit.*;
import org.bukkit.entity.Player;

public class LunarWorldManager {

    private final LunarSurvival plugin;
    private static final String MOON_WORLD_NAME = "lunar_moon";

    public LunarWorldManager(LunarSurvival plugin) {
        this.plugin = plugin;
        createMoonWorld();
    }

    private void createMoonWorld() {
        World moonWorld = Bukkit.getWorld(MOON_WORLD_NAME);
        if (moonWorld == null) {
            WorldCreator creator = new WorldCreator(MOON_WORLD_NAME);
            creator.environment(World.Environment.NORMAL);
            creator.generator("LunarSurvival"); // Utilise MoonChunkGenerator via getDefaultWorldGenerator()
            
            
            moonWorld = creator.createWorld();
            if (moonWorld != null) {
                configureMoonWorld(moonWorld);
                plugin.getLogger().info("Monde lunaire cree : " + MOON_WORLD_NAME);
            }
        } else {
            configureMoonWorld(moonWorld);
            plugin.getLogger().info("Monde lunaire charge : " + MOON_WORLD_NAME);
        }
    }

    private void configureMoonWorld(World world) {
        world.setDifficulty(Difficulty.HARD);
        world.setTime(6000);
        world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE,   false);
        world.setGameRule(GameRule.DO_WEATHER_CYCLE,    false);
        world.setGameRule(GameRule.MOB_SPAWNING,        true);
        world.setGameRule(GameRule.DO_FIRE_TICK,        false);
        world.setGameRule(GameRule.NATURAL_REGENERATION,false);
        world.setGameRule(GameRule.ANNOUNCE_ADVANCEMENTS,true);
        world.setPVP(true);
        world.setThundering(false);
        world.setStorm(false);
        WorldBorder border = world.getWorldBorder();
        border.setCenter(0, 0);
        border.setSize(1000);
    }

    public void teleportToMoon(Player player) {
        World moonWorld = Bukkit.getWorld(MOON_WORLD_NAME);
        if (moonWorld == null) { player.sendMessage("§cErreur : monde lunaire introuvable !"); return; }

        Location spawnLoc = moonWorld.getSpawnLocation();
        spawnLoc.setY(moonWorld.getHighestBlockYAt(0, 0) + 1);
        player.teleport(spawnLoc);

        // Titre via Adventure API — identique Java + Bedrock
        BedrockCompat.sendTitle(player,
            BedrockCompat.TITLE_WELCOME,
            BedrockCompat.TITLE_WELCOME_SUB,
            10, 80, 20
        );

        // Son sur Java + Bedrock
        player.playSound(player.getLocation(), Sound.AMBIENT_CAVE, 0.3f, 0.5f);

        // Messages sans emoji
        player.sendMessage(BedrockCompat.MSG_WELCOME_LINE);
        player.sendMessage(BedrockCompat.MSG_WELCOME_1);
        player.sendMessage(BedrockCompat.MSG_WELCOME_2);
        player.sendMessage(BedrockCompat.MSG_WELCOME_3);
        player.sendMessage(BedrockCompat.MSG_WELCOME_4);
        player.sendMessage(BedrockCompat.MSG_WELCOME_5);
        player.sendMessage(BedrockCompat.MSG_WELCOME_LINE);
    }

    public void openReturnPortal(Player player) {
        player.sendMessage("§a§l[LUNAR] Un portail de retour vient d'apparaitre !");
        World overworld = Bukkit.getWorlds().get(0);
        player.teleport(overworld.getSpawnLocation());
    }

    public String getMoonWorldName() { return MOON_WORLD_NAME; }
    public World  getMoonWorld()     { return Bukkit.getWorld(MOON_WORLD_NAME); }
}
