package fr.lunar.survival.managers;

import fr.lunar.survival.BedrockCompat;
import fr.lunar.survival.LunarSurvival;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class MeteorManager {

    private final LunarSurvival plugin;
    private final Random random = new Random();

    private static final long MIN_INTERVAL_TICKS = 20L * 60 * 5;
    private static final long MAX_INTERVAL_TICKS = 20L * 60 * 15;

    public MeteorManager(LunarSurvival plugin) { this.plugin = plugin; }

    public void startTask() { scheduleNextMeteor(); }

    private void scheduleNextMeteor() {
        long delay = MIN_INTERVAL_TICKS + (long)(random.nextDouble() * (MAX_INTERVAL_TICKS - MIN_INTERVAL_TICKS));
        new BukkitRunnable() {
            @Override
            public void run() {
                List<Player> moonPlayers = Bukkit.getOnlinePlayers().stream()
                    .filter(p -> plugin.getOxygenManager().isOnMoon(p))
                    .collect(Collectors.toList());
                if (!moonPlayers.isEmpty()) {
                    launchMeteor(moonPlayers.get(random.nextInt(moonPlayers.size())));
                }
                scheduleNextMeteor();
            }
        }.runTaskLater(plugin, delay);
    }

    public void launchMeteor(Player nearPlayer) {
        World world = nearPlayer.getWorld();
        int dx = (random.nextBoolean() ? 1 : -1) * (20 + random.nextInt(20));
        int dz = (random.nextBoolean() ? 1 : -1) * (20 + random.nextInt(20));
        Location groundTarget = nearPlayer.getLocation().add(dx, 0, dz);
        groundTarget.setY(world.getHighestBlockYAt(groundTarget));
        Location spawnLoc = groundTarget.clone().add(0, 60, 0);

        // Message sans emoji — compatible Bedrock
        Bukkit.getOnlinePlayers().stream()
            .filter(p -> plugin.getOxygenManager().isOnMoon(p))
            .forEach(p -> {
                p.sendMessage(BedrockCompat.MSG_METEOR_WARNING);
                // Son sur Java + Bedrock
                p.playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.5f, 0.3f);
            });

        Fireball fireball = (Fireball) world.spawnEntity(spawnLoc, EntityType.FIREBALL);
        Vector dir = groundTarget.toVector().subtract(spawnLoc.toVector()).normalize().multiply(1.5);
        fireball.setDirection(dir);
        fireball.setYield(3.0f);
        fireball.setIsIncendiary(false);

        // Trailee de particules — FLAME et SMOKE_LARGE mappes par Geyser
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (fireball.isDead() || ticks++ > 200) { cancel(); return; }
                world.spawnParticle(Particle.FLAME,       fireball.getLocation(), 5, 0.2, 0.2, 0.2, 0.05);
                world.spawnParticle(Particle.SMOKE_LARGE, fireball.getLocation(), 3, 0.2, 0.2, 0.2, 0.02);
            }
        }.runTaskTimer(plugin, 0L, 2L);
    }

    public void triggerMeteorShower(Player nearPlayer, int count) {
        for (int i = 0; i < count; i++) {
            final int idx = i;
            new BukkitRunnable() {
                @Override public void run() { launchMeteor(nearPlayer); }
            }.runTaskLater(plugin, idx * 40L);
        }
    }
}
