package fr.lunar.survival.managers;

import fr.lunar.survival.LunarSurvival;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.*;

public class GravityManager {

    private final LunarSurvival plugin;

    public GravityManager(LunarSurvival plugin) {
        this.plugin = plugin;
    }

    public void startTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    if (!plugin.getOxygenManager().isOnMoon(player)) {
                        // Remove lunar gravity effects if player left moon somehow
                        removeLunarEffects(player);
                        continue;
                    }
                    applyLunarGravity(player);
                }
            }
        }.runTaskTimer(plugin, 10L, 10L); // Every 0.5s for smooth effect
    }

    public void applyLunarGravity(Player player) {
        // Slow Falling = reduced gravity feel
        player.addPotionEffect(new PotionEffect(
            PotionEffectType.SLOW_FALLING,
            30,   // 1.5s, refreshed every 0.5s → permanent
            0,
            false, // no ambient particles
            false  // no icon (already in action bar)
        ));

        // Jump Boost II = higher jumps (moon gravity)
        player.addPotionEffect(new PotionEffect(
            PotionEffectType.JUMP_BOOST,
            30,
            2,    // Level III jump (0-indexed)
            false,
            false
        ));
    }

    public void removeLunarEffects(Player player) {
        player.removePotionEffect(PotionEffectType.SLOW_FALLING);
        player.removePotionEffect(PotionEffectType.JUMP_BOOST);
    }
}
